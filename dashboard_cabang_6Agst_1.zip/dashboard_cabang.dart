import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:laporan_keuangan1/log_page.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:laporan_keuangan1/InputTransaksiPage.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:pdf/pdf.dart';
import 'package:flutter/rendering.dart';
import 'package:laporan_keuangan1/pages/laporanLRPage.dart';
import 'package:laporan_keuangan1/pages/laporanInvestor.dart';
import 'package:laporan_keuangan1/pages/laporanStok.dart';
import 'package:laporan_keuangan1/log_service.dart';


class DashboardCabang extends StatefulWidget {
  final String idCabang;
  final String namaCabang;


  const DashboardCabang({
    super.key,
    required this.idCabang,
    required this.namaCabang,
  });



  @override
  State<DashboardCabang> createState() => _DashboardCabangState();

  Future<List<Map<String, dynamic>>> _fetchOmzetFromSupabase() async {
    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) {
        debugPrint("❌ User belum login.");
        return [];
      }

      // Ambil profil untuk dapatkan id_cabang
      final profileRes = await Supabase.instance.client
          .from('profiles')
          .select('id_cabang')
          .eq('id', user.id)
          .maybeSingle();

      if (profileRes == null || profileRes['id_cabang'] == null) {
        debugPrint("❌ id_cabang tidak ditemukan di profiles.");
        return [];
      }

      final String idCabang = profileRes['id_cabang'];

      // Ambil data omzet dari Supabase
      final omzetRes = await Supabase.instance.client
          .from('rekap_omzet_harian')
          .select('tanggal, total_omzet')
          .eq('id_cabang', idCabang)
          .order('tanggal', ascending: true);

      if (omzetRes == null || omzetRes.isEmpty) {
        debugPrint("⚠️ Tidak ada data omzet.");
        return [];
      }

      return List<Map<String, dynamic>>.from(omzetRes);
    } catch (e, st) {
      debugPrint("❌ Error ambil omzet: $e\n$st");
      return [];
    }
  }
}

Widget _buildLaporanCard({
  required String title,
  required String subtitle,
  required String nominal,
  required VoidCallback onDetailPressed,
}) {
  return Card(
    elevation: 2,
    color: Colors.white, // Card putih
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          const SizedBox(height: 4),
          Text(subtitle,
              style: const TextStyle(color: Colors.black54, fontSize: 14)),
          const SizedBox(height: 8),
          Text(nominal,
              style: const TextStyle(
                  color: Colors.orange,
                  fontSize: 16,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green.shade100, // Tombol hijau muda
                foregroundColor: Colors.green.shade800, // Teks hijau tua
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                elevation: 0, // Biar rata tanpa bayangan
              ),
              onPressed: onDetailPressed,
              child: const Text("Detail"),
            ),
          ),
        ],
      ),
    ),
  );
}

class _DashboardCabangState extends State<DashboardCabang> {
  int _selectedIndex = 0;

  final GlobalKey _chartKeySales = GlobalKey();
  final GlobalKey _chartKeyMato = GlobalKey();
  final GlobalKey _chartKeyHPP = GlobalKey();
  final logService = LogService();


  late final String cabangIdKamu;
  late final String namaCabangKamu;
  String? userEmail;

  DateTime? _startDate;
  DateTime? _endDate;


  final List<Map<String, dynamic>> _navItems = [
    {'label': 'Dashboard', 'icon': Icons.dashboard},
    {'label': 'Laporan', 'icon': Icons.insert_chart},
    {'label': 'Mato Cabang', 'icon': Icons.pie_chart},
    {'label': 'Transaksi', 'icon': Icons.receipt_long},
  ];



  Future<List<Map<String, dynamic>>> _fetchSales100Hari() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) throw Exception("User belum login");

    final profile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = profile?['id_cabang'];
    if (idCabang == null) throw Exception("ID cabang tidak ditemukan");

    final queryBuilder = supabase
        .from('sales_100_hari')
        .select()
        .eq('id_cabang', idCabang);

    if (_startDate != null) {
      queryBuilder.filter('tanggal', 'gte', _startDate!.toIso8601String());
    }
    if (_endDate != null) {
      queryBuilder.filter('tanggal', 'lte', _endDate!.toIso8601String());
    }

    final response = await queryBuilder.order('tanggal');

    return List<Map<String, dynamic>>.from(response);
  }

  Future<List<Map<String, dynamic>>> _fetchRekapTransaksi() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) {
      throw Exception("User belum login.");
    }

    final userProfile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = userProfile?['id_cabang'];
    if (idCabang == null) throw Exception("ID Cabang tidak ditemukan.");

    final response = await supabase
        .from('rekap_transaksi_per_tanggal') // ← ambil dari view
        .select()
        .eq('id_cabang', idCabang)
        .order('tanggal', ascending: false)
        .limit(10);

    return List<Map<String, dynamic>>.from(response);
  }

  Future<List<Map<String, dynamic>>> _fetchPegawaiFromSupabase() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) {
      throw Exception("User tidak ditemukan.");
    }

    // Ambil id_cabang dari profil user
    final userProfile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = userProfile?['id_cabang'];
    if (idCabang == null) throw Exception("ID Cabang tidak ditemukan.");

    final response = await supabase
        .from('profiles')
        .select()
        .eq('id_cabang', idCabang)
        .order('nama');

    return List<Map<String, dynamic>>.from(response);
  }

  Future<Map<String, dynamic>> _fetchProfile() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) throw Exception('User tidak login');

    final data = await Supabase.instance.client
        .from('profiles')
        .select()
        .eq('id', user.id)
        .maybeSingle();

    if (data == null) throw Exception('Profil tidak ditemukan');
    return data;
  }

  Future<List<Map<String, dynamic>>> _getDetailTransaksi(String tanggal) async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) return [];

    final profile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = profile?['id_cabang'];
    if (idCabang == null) return [];

    final response = await supabase
        .from('transaksi_harian')
        .select()
        .eq('id_cabang', idCabang)
        .eq('tanggal', tanggal)
        .order('jenis_transaksi');

    return List<Map<String, dynamic>>.from(response);
  }

  @override
  void initState() {
    super.initState();
    _fetchOmzetFromSupabase();
    cabangIdKamu = widget.idCabang;
    namaCabangKamu = widget.namaCabang;
    userEmail = Supabase.instance.client.auth.currentUser?.email;

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Builder(
                  builder: (context) =>
                      IconButton(
                        icon: const Icon(
                            Icons.menu, size: 34, color: Colors.black),
                        onPressed: () => Scaffold.of(context).openDrawer(),
                      ),
                ),
                const SizedBox(width: 16),
                Row(
                  children: [
                    Image.asset('assets/logobg.png', height: 85),
                    const SizedBox(width: 10),
                    RichText(
                      text: const TextSpan(
                        children: [
                          TextSpan(
                            text: 'SIMPANG ',
                            style: TextStyle(color: Colors.black, fontSize: 30),
                          ),
                          TextSpan(
                            text: 'RAYA',
                            style: TextStyle(
                              color: Colors.red,
                              fontSize: 30,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.refresh, size: 20),
                          tooltip: 'Refresh Profil',
                          onPressed: () async {
                            await _fetchProfile();
                            setState(() {}); // Supaya tampilan diperbarui
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text('Berhasil refresh halaman')),
                            );
                          },
                        ),
                        const Text(
                          'ADMIN CABANG',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                    Text(
                      widget.namaCabang.toUpperCase(),
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFFFD1D1), Colors.white],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Admin Cabang',
                      style: TextStyle(color: Colors.black, fontSize: 20)),
                  SizedBox(height: 8),
                  Text(userEmail ?? 'Email tidak tersedia',
                      style: TextStyle(color: Colors.black54)),
                ],
              ),
            ),

            ListTile(
              leading: const Icon(Icons.home),
              title: const Text('Beranda'),
              onTap: () {
                Navigator.pop(context);
                setState(() => _selectedIndex = 0);
              },
            ),
            ListTile(
              leading: const Icon(Icons.attach_money),
              title: const Text('Input Pengeluaran Pokok'),
              onTap: () {
                Navigator.pop(context);
                Future.delayed(const Duration(milliseconds: 300), () {
                  Navigator.pushNamed(context, '/input-omzet');
                });
              },
            ),
            ListTile(
              leading: const Icon(Icons.attach_money),
              title: const Text('Input Laba Bersih'),
              onTap: () {
                Navigator.pop(context);
                Future.delayed(const Duration(milliseconds: 300), () {
                  final cabangId = 'CB004'; // ambil dari login/sesi
                  final tanggal = DateTime.now(); // bisa diganti ke tanggal pilihan

                  Navigator.pushNamed(
                    context,
                    '/input-laba',
                    arguments: {
                      'idCabang': cabangId,
                      'tanggal': tanggal,
                    },
                  );
                });
              },
            ),

            ListTile(
              leading: const Icon(Icons.attach_money),
              title: const Text('Input Transaksi'),
              onTap: () {
                Navigator.pop(context);
                Future.delayed(const Duration(milliseconds: 300), () {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (context) =>
                          InputTransaksiPage(cabangId: widget.idCabang)));
                });
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.history),
              title: const Text('Log Aktivitas'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const LogPage()),
                );
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Keluar'),
              onTap: () async {
                final supabase = Supabase.instance.client;
                final user = supabase.auth.currentUser;

                if (user != null) {
                  final userData = await supabase
                      .from('profiles')
                      .select('nama, role')
                      .eq('id', user.id)
                      .maybeSingle();

                  if (userData != null) {
                    final nama = userData['nama'];
                    final role = userData['role'];

                    final logService = LogService();
                    await logService.addLog(
                      aktivitas: "Logout",
                      halaman: "Auth",
                      detail: "User $nama ($role) melakukan logout",
                    );
                  }
                }

                await supabase.auth.signOut();
                if (context.mounted) {
                  Navigator.pushReplacementNamed(context, '/login');
                }
              },
            ),
          ],
        ),
      ),

      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Color(0xFFFFD1D1), Colors.white],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 20),
                Wrap(
                  spacing: 20,
                  runSpacing: 16,
                  alignment: WrapAlignment.center,
                  children: List.generate(_navItems.length, (index) {
                    return _buildNavButton(index);
                  }),
                ),
                const SizedBox(height: 30),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: _buildContent(),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<List<Map<String, dynamic>>> _fetchHPPFromSupabase() async {
    try {
      final supabase = Supabase.instance.client;

      // Query untuk mengambil data HPP per cabang per hari
      var query = supabase
          .from('bahan_pokok')
          .select('tanggal, id_cabang, total') // Pilih kolom yang dibutuhkan
          .order('tanggal', ascending: true) as PostgrestFilterBuilder; // Pastikan casting ke PostgrestFilterBuilder

      // Filter tanggal awal
      if (_startDate != null) {
        query = query.gte('tanggal', DateFormat('yyyy-MM-dd').format(_startDate!));
      }

      // Filter tanggal akhir
      if (_endDate != null) {
        query = query.lte('tanggal', DateFormat('yyyy-MM-dd').format(_endDate!));
      }

      final response = await query;

      // Agregasi data untuk mendapatkan total HPP per cabang per hari
      final aggregatedData = <String, double>{};

      for (var item in response) {
        final cabangId = item['id_cabang'];
        final totalHPP = item['total'] ?? 0.0; // Mengganti null dengan 0.0

        if (aggregatedData.containsKey(cabangId)) {
          aggregatedData[cabangId] = aggregatedData[cabangId]! + totalHPP;
        } else {
          aggregatedData[cabangId] = totalHPP;
        }
      }

      // Ubah data menjadi format yang diinginkan
      final result = aggregatedData.entries.map((e) {
        return {
          'id_cabang': e.key,
          'total': e.value,
        };
      }).toList();

      return result;
    } catch (e) {
      debugPrint("❌ Error fetch HPP: $e");
      return [];
    }
  }

  Widget _buildLaporanTab(BuildContext context) {
    final currencyFormat = NumberFormat.currency(
      locale: 'id',
      symbol: 'Rp ',
      decimalDigits: 0,
    );

    // Contoh data
    final labaRugi = currencyFormat.format(25000000);
    final investor = currencyFormat.format(5000000);
    final stokGudang = currencyFormat.format(12000000);

    return SingleChildScrollView(
      child: Column(
        children: [
          _buildLaporanCard(
            title: "Laporan Laba Rugi",
            subtitle: "Ringkasan pemasukan & pengeluaran",
            nominal: labaRugi,
            onDetailPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const LaporanLRPage()),
              );
            },
          ),
          _buildLaporanCard(
            title: "Laporan Investor",
            subtitle: "Pembagian hasil untuk investor",
            nominal: investor,
            onDetailPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => LaporanInvestorPage(idCabang: widget.idCabang)),
              );
            },
          ),
          _buildLaporanCard(
            title: "Laporan ALPB",
            subtitle: "Analisa pemakaian barang",
            nominal: stokGudang,
            onDetailPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => LaporanStok(idCabang: widget.idCabang),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildNavButton(int index) {
    bool isSelected = _selectedIndex == index;
    return SizedBox(
      width: 200,
      height: 45,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: isSelected ? Colors.red.shade100 : Colors.white,
          foregroundColor: Colors.black,
          elevation: isSelected ? 4 : 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(50),
          ),
        ),
        onPressed: () => setState(() => _selectedIndex = index),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(_navItems[index]['icon'], size: 20),
            const SizedBox(width: 8),
            Text(
              _navItems[index]['label'],
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSalesChart(List<Map<String, dynamic>> data) {
    final List<BarChartGroupData> barGroups = [];
    final List<String> tanggalList = [];

    for (int i = 0; i < data.length; i++) {
      final item = data[i];
      final double y = (item['total_omset'] ?? 0).toDouble();
      final String tanggal = item['tanggal'] ?? '';
      tanggalList.add(tanggal);

      barGroups.add(
        BarChartGroupData(
          x: i,
          barRods: [
            BarChartRodData(toY: y, color: Colors.green),
          ],
        ),
      );
    }

    return AspectRatio(
      aspectRatio: 1.6,
      child: BarChart(
        BarChartData(
          barGroups: barGroups,
          titlesData: FlTitlesData(
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (double value, TitleMeta meta) {
                  final int index = value.toInt();

                  // Pastikan index valid
                  if (index < 0 || index >= tanggalList.length) {
                    return const SizedBox.shrink();
                  }

                  // Format tanggal
                  final formatted = DateFormat('d MMM').format(DateTime.parse(tanggalList[index]));

                  // Hanya tampilkan setiap 10 hari agar tidak penuh
                  if (index % 10 != 0) return const SizedBox.shrink();

                  // Kembalikan teks label
                  return Text(
                    formatted,
                    style: const TextStyle(fontSize: 10),
                  );
                },

                reservedSize: 36,
                interval: 1,
              ),
            ),
            topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: true),
            ),
          ),
          borderData: FlBorderData(show: false),
          gridData: FlGridData(show: true),
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _applyDateFilter(List<Map<String, dynamic>> data) {
    return data.where((item) {
      try {
        final tanggal = DateTime.parse(item['tanggal']);
        if (_startDate != null && tanggal.isBefore(_startDate!)) return false;
        if (_endDate != null && tanggal.isAfter(_endDate!)) return false;
        return true;
      } catch (e) {
        return false; // Skip jika parsing gagal
      }
    }).toList();
  }

  Widget _buildOmzetLineChart(
      List<Map<String, dynamic>> data, {
        String filterType = 'all',
      }) {
    if (data.isEmpty) {
      return const Center(child: Text("Tidak ada data"));
    }

    // Ambil dan akumulasi omzet dari semua tanggal
    final omzetPerTanggal = <String, double>{};

    for (var item in data) {
      final tanggal = item['tanggal'];
      final omzet = (item['total_omzet'] as num).toDouble();
      omzetPerTanggal[tanggal] = (omzetPerTanggal[tanggal] ?? 0) + omzet;
    }

    final sortedKeys = omzetPerTanggal.keys.toList()..sort();
    final omzetValues = sortedKeys.map((k) => omzetPerTanggal[k]!).toList();

    final minValue = omzetValues.reduce((a, b) => a < b ? a : b);
    final maxValue = omzetValues.reduce((a, b) => a > b ? a : b);

    // Naikkan jarak bawah supaya garis tidak terlalu mepet
    final chartMinY = (minValue * 0.2).clamp(0, double.infinity); // dari 0.8 → 0.7
    final chartMaxY = maxValue * 1.2;

    final spots = List.generate(sortedKeys.length, (i) {
      return FlSpot(i.toDouble(), omzetPerTanggal[sortedKeys[i]]!);
    });


    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.6),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.black.withOpacity(0.1), width: 1),
      ),
      child: SizedBox(
        height: 300,
        child: LineChart(
          LineChartData(
            minX: -0.3,
            maxX: sortedKeys.length - 0.7,
            minY: chartMinY.toDouble(),
            maxY: chartMaxY.toDouble(),
            gridData: FlGridData(show: false),
            titlesData: FlTitlesData(
              leftTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 60,
                  getTitlesWidget: (value, meta) {
                    // Tampilkan label hanya untuk nilai yang ada di data
                    final yValues = omzetPerTanggal.values.toSet();
                    if (!yValues.contains(value)) return const SizedBox.shrink();

                    if (value >= 1000000) {
                      return Text("Rp ${(value / 1000000).toStringAsFixed(2)} jt",
                          style: const TextStyle(fontSize: 11));
                    } else if (value >= 1000) {
                      return Text("Rp ${(value / 1000).toStringAsFixed(0)} rb",
                          style: const TextStyle(fontSize: 11));
                    }
                    return Text("Rp ${value.toStringAsFixed(0)}",
                        style: const TextStyle(fontSize: 11));
                  },
                ),
              ),
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  interval: 1,
                  getTitlesWidget: (value, meta) {
                    int index = value.toInt();
                    if (index < 0 || index >= sortedKeys.length) {
                      return const SizedBox();
                    }

                    // Cek posisi pixel untuk menentukan apakah label terlalu di luar chart
                    final distanceFromLeft = value - meta.min;
                    final distanceFromRight = meta.max - value;

                    if (distanceFromLeft < 0.1 || distanceFromRight < 0.1) {
                      // Label terlalu di ujung luar → hilangkan
                      return const SizedBox();
                    }

                    return Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(
                        DateFormat('dd MMM').format(DateTime.parse(sortedKeys[index])),
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    );
                  },
                ),
              ),
              topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
              rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            ),
            borderData: FlBorderData(
              show: true,
              border: Border.all(color: Colors.black),
            ),
            lineBarsData: [
              // Garis utama (omzet)
              LineChartBarData(
                spots: spots,
                isCurved: false,
                color: Colors.blueGrey,
                barWidth: 3,
                dotData: FlDotData(show: false),
              ),
              // Garis bantu vertikal pendek (hanya dari chartMinY ke titik data)
              ...spots.map((spot) {
                return LineChartBarData(
                  spots: [
                    FlSpot(spot.x, chartMinY.toDouble()),
                    FlSpot(spot.x, spot.y),
                  ],
                  isCurved: false,
                  color: Colors.black.withOpacity(0.4),
                  barWidth: 2,
                  dashArray: [4, 4],
                  dotData: FlDotData(show: false),
                );
              }).toList(),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _exportChartToPdf(GlobalKey chartKey) async {
    final pdf = pw.Document();
    final image = await WidgetWraper.wrapWidgetToImage(chartKey);

    if (image != null) {
      pdf.addPage(
        pw.Page(
          build: (pw.Context context) => pw.Center(
            child: pw.Image(pw.MemoryImage(image)),
          ),
        ),
      );
      await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => pdf.save(),
      );
    }
  }

  // Tambahkan variabel state untuk filter
  String _selectedOmzetFilter = 'all'; // all | month | 100days

  Future<List<Map<String, dynamic>>> _fetchOmzetFromSupabase() async {
    try {
      final supabase = Supabase.instance.client;

      final response = await supabase
          .from('rekap_omzet_harian')
          .select('tanggal, total_omzet')
          .order('tanggal', ascending: true);

      // Pastikan hasil dikonversi ke List<Map<String, dynamic>>
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint("❌ Error fetch omzet: $e");
      return [];
    }
  }

  Widget _buildContent() {
    switch (_selectedIndex) {
      case 0:
        return SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 32),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Filter Tanggal',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: _startDate ?? DateTime.now(),
                            firstDate: DateTime(2020),
                            lastDate: DateTime.now(),
                          );
                          if (picked != null) {
                            setState(() => _startDate = picked);
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            _startDate != null
                                ? 'Dari: ${DateFormat('dd MMM yyyy').format(_startDate!)}'
                                : 'Pilih Tanggal Awal',
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: _endDate ?? DateTime.now(),
                            firstDate: DateTime(2020),
                            lastDate: DateTime.now(),
                          );
                          if (picked != null) {
                            setState(() => _endDate = picked);
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            _endDate != null
                                ? 'Sampai: ${DateFormat('dd MMM yyyy').format(_endDate!)}'
                                : 'Pilih Tanggal Akhir',
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      onPressed: () => setState(() {}),
                      child: const Text('Tampilkan'),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                const Text(
                  'Grafik Sales',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),

                FutureBuilder<List<Map<String, dynamic>>>(
                  future: _fetchSales100Hari(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    } else if (snapshot.hasError) {
                      return Text('Gagal memuat data sales: ${snapshot.error}');
                    }

                    // === FILTER TANGGAL GLOBAL ===
                    final filteredData = _applyDateFilter(snapshot.data ?? []);

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RepaintBoundary(
                          key: _chartKeySales,
                          child: _buildSalesChart(filteredData), // pakai filteredData
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          onPressed: () => _exportChartToPdf(_chartKeySales),
                          icon: const Icon(Icons.picture_as_pdf),
                          label: const Text('Export Sales ke PDF'),
                        ),
                      ],
                    );
                  },
                ),

                const SizedBox(height: 32),
                const Text(
                  'Omzet Cabang',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),


                FutureBuilder<List<Map<String, dynamic>>>(
                  future: _fetchOmzetFromSupabase(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    } else if (snapshot.hasError) {
                      return Text('Gagal memuat omzet: ${snapshot.error}');
                    }

                    // Ambil data dari snapshot
                    final allData = snapshot.data ?? [];

                    // Filter data sesuai tanggal yang dipilih pengguna
                    final filteredData = _applyDateFilter(snapshot.data ?? []);

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RepaintBoundary(
                          key: _chartKeyMato,
                          child: _buildOmzetLineChart(filteredData),
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          onPressed: () => _exportChartToPdf(_chartKeyMato),
                          icon: const Icon(Icons.picture_as_pdf),
                          label: const Text('Export Omzet ke PDF'),
                        ),
                      ],
                    );
                  },
                ),

                const SizedBox(height: 32),
                const Text(
                  'Grafik HPP',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),

                FutureBuilder<List<Map<String, dynamic>>>(
                  future: _fetchHPPFromSupabase(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    } else if (snapshot.hasError) {
                      return Text('Gagal memuat HPP: ${snapshot.error}');
                    }

                    // === FILTER TANGGAL GLOBAL ===
                    final allData = snapshot.data ?? [];
                    final filteredData = _applyDateFilter(allData); // fungsi helper filter tanggal

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RepaintBoundary(
                          key: _chartKeyHPP,
                          child: _buildOmzetLineChart(filteredData), // Gunakan fungsi chart omzet
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          onPressed: () => _exportChartToPdf(_chartKeyHPP),
                          icon: const Icon(Icons.picture_as_pdf),
                          label: const Text('Export HPP ke PDF'),
                        ),
                      ],
                    );
                  },
                ),
              ],
            ),
          ),
        );

      case 1:
        return _buildLaporanTab(context);
      case 2:
        return _buildMatoBoxList();
      case 3:
        return FutureBuilder<List<Map<String, dynamic>>>(
          future: _fetchRekapTransaksi(), // Panggil fungsi ambil data
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(
                  child: Text('Terjadi kesalahan: ${snapshot.error}'));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text('Belum ada data transaksi.'));
            }

            final data = snapshot.data!;
            return _buildRekapTransaksi(data); // Panggil widget builder
          },
        );
      default:
        return const SizedBox(); // fallback jika _selectedIndex di luar 0–3
    }
  }

  final supabase = Supabase.instance.client;

  void _showDetailTransaksi(BuildContext context, String tanggal) async {
    final detail = await _getDetailTransaksi(tanggal);

    // Urutkan: pemasukan dulu (positif), lalu pengeluaran (negatif)
    detail.sort((a, b) {
      final jumlahA = a['jumlah'] as int;
      final jumlahB = b['jumlah'] as int;
      // Pemasukan positif -> tampil dulu, jadi sort menurun dari besar ke kecil
      return jumlahB.compareTo(jumlahA);
    });

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Detail Transaksi $tanggal'),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: detail.length,
              itemBuilder: (context, index) {
                final item = detail[index];
                final jenis = item['jenis_transaksi'];
                final jumlah = item['jumlah'];
                final formatted = NumberFormat.currency(
                    locale: 'id', symbol: 'Rp ', decimalDigits: 0).format(
                    jumlah.abs());
                final isPengeluaran = jumlah < 0;

                return ListTile(
                  leading: Icon(
                      isPengeluaran ? Icons.remove_circle : Icons.add_circle,
                      color: isPengeluaran ? Colors.red : Colors.green),
                  title: Text(jenis),
                  trailing: Text(formatted, style: TextStyle(fontSize: 22,
                      color: isPengeluaran ? Colors.red : Colors.green)),
                );
              },
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context),
                child: const Text('Tutup'))
          ],
        );
      },
    );
  }

// Fungsi dialog edit data pegawai
  void _showDetailMatoDialog(BuildContext context,
      Map<String, dynamic> pegawai) {
    final jabatanController = TextEditingController(
        text: pegawai['jabatan'] ?? '');
    final mataController = TextEditingController(
        text: (pegawai['skor_mato'] ?? '0').toString());
    final nilaiPerMataController = TextEditingController(
        text: (pegawai['nilai_per_mata'] ?? '0').toString());
    final pinjamanController = TextEditingController(
        text: (pegawai['pinjaman'] ?? '0').toString());
    final bonMakanController = TextEditingController(
        text: (pegawai['bon_makan'] ?? '0').toString());
    final bonGudangController = TextEditingController(
        text: (pegawai['bon_gudang'] ?? '0').toString());
    final potAbsenController = TextEditingController(
        text: (pegawai['pot_absen'] ?? '0').toString());
    final absenController = TextEditingController(
        text: (pegawai['absen'] ?? '0').toString());
    final uangServisController = TextEditingController(
        text: (pegawai['uang_servis'] ?? '0').toString());

    int pendapatan = 0;
    int totalMingguan = 0;
    int hasil = 0;
    int totalHasil = 0;

    void hitung() {
      final mata = int.tryParse(mataController.text) ?? 0;
      final nilai = int.tryParse(nilaiPerMataController.text) ?? 0;
      final pinjaman = int.tryParse(pinjamanController.text) ?? 0;
      final bonMakan = int.tryParse(bonMakanController.text) ?? 0;
      final bonGudang = int.tryParse(bonGudangController.text) ?? 0;
      final potAbsen = int.tryParse(potAbsenController.text) ?? 0;
      final uangServis = int.tryParse(uangServisController.text) ?? 0;

      pendapatan = mata * nilai;
      totalMingguan = pinjaman + bonMakan + bonGudang;
      hasil = pendapatan - potAbsen - totalMingguan;
      totalHasil = hasil + uangServis;
    }

    bool isEditMode = true;
    final formatter = NumberFormat.currency(
        locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            hitung();

            return AlertDialog(
              title: Text('Detail Pegawai - ${pegawai['nama']}'),
              content: SingleChildScrollView(
                padding: const EdgeInsets.only(
                    top: 16, left: 8, right: 8, bottom: 8), // ← Tambahkan ini
                child: isEditMode
                    ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildTextField('Jabatan', jabatanController, setState),
                    _buildTextField('Mata', mataController, setState),
                    _buildTextField(
                        'Nilai/Mata', nilaiPerMataController, setState),
                    _buildTextField('Pinjaman', pinjamanController, setState),
                    _buildTextField('Bon Makan', bonMakanController, setState),
                    _buildTextField(
                        'Bon Gudang', bonGudangController, setState),
                    _buildTextField('Pot Absen', potAbsenController, setState),
                    _buildTextField('Absen', absenController, setState),
                    _buildTextField(
                        'Uang Servis', uangServisController, setState),
                    const SizedBox(height: 12),
                    const Text('📌 Perhitungan Otomatis',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    _buildRow('Pendapatan', formatter.format(pendapatan)),
                    _buildRow(
                        'Total Mingguan', formatter.format(totalMingguan)),
                    _buildRow('Hasil', formatter.format(hasil)),
                    _buildRow('Total Hasil', formatter.format(totalHasil)),
                  ],
                )
                    : Column(
                  children: [
                    Table(
                      border: TableBorder.all(),
                      columnWidths: const {
                        0: FixedColumnWidth(140),
                        1: FlexColumnWidth(),
                      },
                      children: [
                        _tr('Mata', mataController.text),
                        _tr('Nilai/Mata', formatter.format(
                            int.tryParse(nilaiPerMataController.text) ?? 0)),
                        _tr('Pendapatan', formatter.format(pendapatan)),
                        _tr('Pinjaman', formatter.format(
                            int.tryParse(pinjamanController.text) ?? 0)),
                        _tr('Bon Makan', formatter.format(
                            int.tryParse(bonMakanController.text) ?? 0)),
                        _tr('Bon Gudang', formatter.format(
                            int.tryParse(bonGudangController.text) ?? 0)),
                        _tr('Pot Absen', formatter.format(
                            int.tryParse(potAbsenController.text) ?? 0)),
                        _tr('Uang Servis', formatter.format(
                            int.tryParse(uangServisController.text) ?? 0)),
                        _tr('Total Mingguan', formatter.format(totalMingguan)),
                        _tr('Hasil', formatter.format(hasil)),
                        _tr('Total Hasil', formatter.format(totalHasil)),
                      ],
                    ),
                    const SizedBox(height: 12),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text(
                      'Tutup', style: TextStyle(color: Colors.red)),
                ),
                ElevatedButton.icon(
                  onPressed: () async {
                    if (isEditMode) {
                      // 🔁 Update ke Supabase (opsional)
                      final supabase = Supabase.instance.client;
                      await supabase.from('profiles').update({
                        'jabatan': jabatanController.text,
                        'skor_mato': int.tryParse(mataController.text),
                        'nilai_per_mata': int.tryParse(nilaiPerMataController.text),
                        'pendapatan': pendapatan,
                        'pinjaman': int.tryParse(pinjamanController.text),
                        'bon_makan': int.tryParse(bonMakanController.text),
                        'bon_gudang': int.tryParse(bonGudangController.text),
                        'pot_absen': int.tryParse(potAbsenController.text),
                        'absen': int.tryParse(absenController.text),
                        'uang_servis': int.tryParse(uangServisController.text),
                        'hasil': hasil,
                        'total_mingguan': totalMingguan,
                        'total_hasil': totalHasil,
                      }).eq('id', pegawai['id']);

                      setState(() => isEditMode = false);
                    } else {
                      setState(() => isEditMode = true);
                    }
                  },
                  icon: Icon(isEditMode ? Icons.save : Icons.edit),
                  label: Text(isEditMode ? 'Simpan Perubahan' : 'Edit Ulang'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildTextField(String label, TextEditingController controller,
      void Function(void Function()) setState) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        onChanged: (_) => setState(() {}),
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  Widget _buildRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  TableRow _tr(String label, String value) {
    return TableRow(
      children: [
        Padding(padding: const EdgeInsets.all(8), child: Text(label)),
        Padding(padding: const EdgeInsets.all(8), child: Text(value)),
      ],
    );
  }

  String _formatRupiah(dynamic value) {
    try {
      if (value == null || value
          .toString()
          .isEmpty) return '-';
      final parsed = double.tryParse(value.toString());
      if (parsed == null) return '-';
      final formatter = NumberFormat.currency(
          locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
      return formatter.format(parsed);
    } catch (_) {
      return '-';
    }
  }

  Widget _buildRekapTransaksi(List<Map<String, dynamic>> data) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Rekap Transaksi Terakhir',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 250,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: data.length,
            separatorBuilder: (context, index) => const SizedBox(width: 16),
            itemBuilder: (context, index) {
              final item = data[index];
              final tanggal = DateFormat('dd MMM yyyy')
                  .format(DateTime.parse(item['tanggal']));
              final total = item['total_transaksi'] ?? 0;
              final keterangan = item['keterangan'] ?? '-';

              return GestureDetector(
                onTap: () {
                  _showDetailTransaksi(context, item['tanggal']);
                  // Bisa juga tampilkan detail jika perlu
                },
                child: Container(
                  width: 240,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: const [
                      BoxShadow(color: Colors.black12, blurRadius: 4)
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tanggal,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text("Total: Rp ${_formatRupiah(total)}",
                          style: const TextStyle(fontSize: 14)),
                      const SizedBox(height: 8),
                      const Text('Keterangan:',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      Text(keterangan,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 13)),
                      const Spacer(),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit, size: 18),
                            onPressed: () =>
                                _editKeteranganTransaksi(
                                    context, item['tanggal']),
                          ),
                          const SizedBox(width: 8),
                          IconButton(
                            icon: const Icon(Icons.delete, size: 18),
                            onPressed: () =>
                                _deleteLaporan(context, item['tanggal']),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Future<void> _editKeteranganTransaksi(BuildContext context,
      String tanggal) async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) return;

    // Ambil id_cabang dari profile
    final userProfile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = userProfile?['id_cabang'];
    if (idCabang == null) return;

    // Ambil salah satu transaksi di tanggal tsb untuk edit keterangannya
    final transaksi = await supabase
        .from('transaksi_harian')
        .select()
        .eq('id_cabang', idCabang)
        .eq('tanggal', tanggal) // format harus "yyyy-MM-dd"
        .limit(1)
        .maybeSingle();

    if (transaksi == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Detail tidak tersedia untuk data rekap.')),
      );
      return;
    }

    final TextEditingController keteranganController =
    TextEditingController(text: transaksi['keterangan'] ?? '');

    showDialog(
      context: context,
      builder: (context) =>
          AlertDialog(
            title: const Text('Edit Keterangan'),
            content: TextField(
              controller: keteranganController,
              decoration: const InputDecoration(labelText: 'Keterangan baru'),
              maxLines: 3,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Batal'),
              ),
              ElevatedButton(
                onPressed: () async {
                  await supabase
                      .from('transaksi_harian')
                      .update({'keterangan': keteranganController.text.trim()})
                      .eq('id', transaksi['id']);
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content: Text('Keterangan berhasil diperbarui')),
                  );
                  setState(() {}); // Refresh tampilan
                },
                child: const Text('Simpan'),
              ),
            ],
          ),
    );
  }

  Future<void> _deleteLaporan(BuildContext context, String tanggal) async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) return;

    final userProfile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = userProfile?['id_cabang'];
    if (idCabang == null) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) =>
          AlertDialog(
            title: const Text('Konfirmasi'),
            content: const Text(
                'Yakin ingin menghapus semua transaksi pada tanggal ini?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Batal'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text('Hapus'),
              ),
            ],
          ),
    );

    if (confirm != true) return;

    try {
      await supabase
          .from('transaksi_harian')
          .delete()
          .eq('id_cabang', idCabang)
          .eq('tanggal', tanggal);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Transaksi berhasil dihapus')),
      );

      setState(() {}); // refresh tampilan
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal menghapus: $e')),
      );
    }
  }


// Widget untuk menampilkan grid box pegawai dan tambah
  TextEditingController _searchController = TextEditingController();
  String _sortOption = 'Tertinggi';

  Widget _buildMatoBoxList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Mato Pegawai',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _searchController,
                decoration: const InputDecoration(
                  hintText: 'Cari nama pegawai...',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
                onChanged: (_) => setState(() {}),
              ),
            ),
            const SizedBox(width: 12),
            DropdownButton<String>(
              value: _sortOption,
              items: ['Tertinggi', 'Terendah'].map((option) {
                return DropdownMenuItem(
                  value: option,
                  child: Text('Sort by $option'),
                );
              }).toList(),
              onChanged: (value) {
                setState(() => _sortOption = value ?? 'Tertinggi');
              },
            ),
          ],
        ),
        const SizedBox(height: 16),
        FutureBuilder<List<Map<String, dynamic>>>(
          future: _fetchPegawaiFromSupabase(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(
                  child: Text('Terjadi kesalahan: ${snapshot.error}'));
            }

            List<Map<String, dynamic>> pegawaiList = snapshot.data ?? [];

            // Filter
            final searchQuery = _searchController.text.toLowerCase();
            pegawaiList = pegawaiList
                .where((e) =>
                (e['nama'] ?? '').toString().toLowerCase().contains(
                    searchQuery))
                .toList();

            // Sort
            pegawaiList.sort((a, b) {
              final aVal = a['skor_mato'] ?? 0;
              final bVal = b['skor_mato'] ?? 0;
              return _sortOption == 'Tertinggi' ? bVal.compareTo(aVal) : aVal
                  .compareTo(bVal);
            });

            return SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: pegawaiList.map((pegawai) {
                  return Container(
                    width: 240,
                    height: 180,
                    margin: const EdgeInsets.only(right: 16),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: const [BoxShadow(
                          color: Colors.black12, blurRadius: 4)
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(pegawai['nama'] ?? '-', style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        Text(pegawai['jabatan'] ?? '-',
                            style: const TextStyle(fontSize: 14)),
                        const Spacer(),
                        Text(
                          "Poin Mato ${pegawai['skor_mato'] ?? 0}",
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.orange,
                          ),
                        ),
                        const SizedBox(height: 8),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () =>
                                _showDetailMatoDialog(context, pegawai),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green.shade100,
                            ),
                            child: const Text('Detail',
                                style: TextStyle(color: Colors.green)),
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            );
          },
        ),
      ],
    );
  }
}

class WidgetWraper {
  static Future<Uint8List?> wrapWidgetToImage(GlobalKey key) async {
    try {
      final boundary = key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      final image = await boundary?.toImage(pixelRatio: 2.0);
      final byteData = await image?.toByteData(format: ui.ImageByteFormat.png);
      return byteData?.buffer.asUint8List();
    } catch (_) {
      return null;
    }
  }
}
