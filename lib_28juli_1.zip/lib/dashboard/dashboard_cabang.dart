import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:laporan_keuangan1/InputTransaksiPage.dart';

class DashboardCabang extends StatefulWidget {
  final String idCabang;
  final String namaCabang;

  const DashboardCabang({
    super.key,
    required this.idCabang,
    required this.namaCabang,
  });

  @override
  State<DashboardCabang> createState() => _DashboardCabangState();
}

class _DashboardCabangState extends State<DashboardCabang> {
  int _selectedIndex = 0;

  late final String cabangIdKamu;
  late final String namaCabangKamu;
  String? userEmail;

  final List<Map<String, dynamic>> _navItems = [
    {'label': 'Dashboard', 'icon': Icons.dashboard},
    {'label': 'Laporan', 'icon': Icons.insert_chart},
    {'label': 'Mato', 'icon': Icons.pie_chart},
    {'label': 'Transaksi', 'icon': Icons.receipt_long},
  ];

  Future<List<Map<String, dynamic>>> _fetchRekapTransaksi() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) {
      throw Exception("User belum login.");
    }

    final userProfile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = userProfile?['id_cabang'];
    if (idCabang == null) throw Exception("ID Cabang tidak ditemukan.");

    final response = await supabase
        .from('rekap_transaksi_per_tanggal') // ← ambil dari view
        .select()
        .eq('id_cabang', idCabang)
        .order('tanggal', ascending: false)
        .limit(10);

    return List<Map<String, dynamic>>.from(response);
  }

  Future<List<Map<String, dynamic>>> _fetchPegawaiFromSupabase() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) {
      throw Exception("User tidak ditemukan.");
    }

    // Ambil id_cabang dari profil user
    final userProfile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = userProfile?['id_cabang'];
    if (idCabang == null) throw Exception("ID Cabang tidak ditemukan.");

    final response = await supabase
        .from('profiles')
        .select()
        .eq('id_cabang', idCabang)
        .order('nama');

    return List<Map<String, dynamic>>.from(response);
  }

  Future<Map<String, dynamic>> _fetchProfile() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) throw Exception('User tidak login');

    final data = await Supabase.instance.client
        .from('profiles')
        .select()
        .eq('id', user.id)
        .maybeSingle();

    if (data == null) throw Exception('Profil tidak ditemukan');
    return data;
  }

  Future<List<Map<String, dynamic>>> _getDetailTransaksi(String tanggal) async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) return [];

    final profile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = profile?['id_cabang'];
    if (idCabang == null) return [];

    final response = await supabase
        .from('transaksi_harian')
        .select()
        .eq('id_cabang', idCabang)
        .eq('tanggal', tanggal)
        .order('jenis_transaksi');

    return List<Map<String, dynamic>>.from(response);
  }

  @override
  void initState() {
    super.initState();
    cabangIdKamu = widget.idCabang;
    namaCabangKamu = widget.namaCabang;
    userEmail = Supabase.instance.client.auth.currentUser?.email;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Builder(
                  builder: (context) =>
                      IconButton(
                        icon: const Icon(
                            Icons.menu, size: 34, color: Colors.black),
                        onPressed: () => Scaffold.of(context).openDrawer(),
                      ),
                ),
                const SizedBox(width: 16),
                Row(
                  children: [
                    Image.asset('assets/logobg.png', height: 85),
                    const SizedBox(width: 10),
                    RichText(
                      text: const TextSpan(
                        children: [
                          TextSpan(
                            text: 'SIMPANG ',
                            style: TextStyle(color: Colors.black, fontSize: 30),
                          ),
                          TextSpan(
                            text: 'RAYA',
                            style: TextStyle(
                              color: Colors.red,
                              fontSize: 30,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.refresh, size: 20),
                          tooltip: 'Refresh Profil',
                          onPressed: () async {
                            await _fetchProfile();
                            setState(() {}); // Supaya tampilan diperbarui
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Berhasil refresh halaman')),
                            );
                          },
                        ),
                        const Text(
                          'ADMIN CABANG',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                    Text(
                      widget.namaCabang.toUpperCase(),
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFFFD1D1), Colors.white],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Admin Cabang',
                      style: TextStyle(color: Colors.black, fontSize: 20)),
                  SizedBox(height: 8),
                  Text(userEmail ?? 'Email tidak tersedia',
                      style: TextStyle(color: Colors.black54)),
                ],
              ),
            ),

            ListTile(
              leading: const Icon(Icons.home),
              title: const Text('Beranda'),
              onTap: () {
                Navigator.pop(context);
                setState(() => _selectedIndex = 0);
              },
            ),
            ListTile(
              leading: const Icon(Icons.attach_money),
              title: const Text('Input Pengeluaran Pokok'),
              onTap: () {
                Navigator.pop(context);
                Future.delayed(const Duration(milliseconds: 300), () {
                  Navigator.pushNamed(context, '/input-omzet');
                });
              },
            ),
            ListTile(
              leading: const Icon(Icons.attach_money),
              title: const Text('Ketentuan permata'),
              onTap: () {
                Navigator.pop(context);
                Future.delayed(const Duration(milliseconds: 300), () {
                  final cabangId = 'CB001'; // ambil dari session Supabase / login
                  Navigator.pushNamed(
                      context, '/input-permata', arguments: cabangId);
                });
              },
            ),
            ListTile(
              leading: const Icon(Icons.attach_money),
              title: const Text('Input Transaksi Harian'),
              onTap: () {
                Navigator.pop(context);
                Future.delayed(const Duration(milliseconds: 300), () {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (context) => InputTransaksiPage(cabangId: widget.idCabang)));
                });
              },
            ),

            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              onTap: () {
                Navigator.pop(context);
                Future.delayed(const Duration(milliseconds: 300), () {
                  Navigator.of(context).pushReplacementNamed('/login');
                });
              },
            ),
          ],
        ),
      ),

      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Color(0xFFFFD1D1), Colors.white],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 20),
                Wrap(
                  spacing: 20,
                  runSpacing: 16,
                  alignment: WrapAlignment.center,
                  children: List.generate(_navItems.length, (index) {
                    return _buildNavButton(index);
                  }),
                ),
                const SizedBox(height: 30),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: _buildContent(),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavButton(int index) {
    bool isSelected = _selectedIndex == index;
    return SizedBox(
      width: 180,
      height: 45,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: isSelected ? Colors.red.shade100 : Colors.white,
          foregroundColor: Colors.black,
          elevation: isSelected ? 4 : 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(50),
          ),
        ),
        onPressed: () => setState(() => _selectedIndex = index),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(_navItems[index]['icon'], size: 20),
            const SizedBox(width: 8),
            Text(
              _navItems[index]['label'],
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }

  Future<List<Map<String, dynamic>>> _fetchLaporanMingguan() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) {
      throw Exception("User belum login.");
    }

    // Ambil UUID cabang dari tabel profiles berdasarkan user ID
    final userProfile = await supabase
        .from('profiles')
        .select('id_cabang') // id_cabang di sini UUID
        .eq('id', user.id)
        .maybeSingle();

    final uuidCabang = userProfile?['id_cabang'];
    if (uuidCabang == null) {
      throw Exception("ID cabang tidak ditemukan di profil user.");
    }

    final now = DateTime.now();
    final firstDayOfWeek = now.subtract(Duration(days: now.weekday - 1));
    final lastDayOfWeek = firstDayOfWeek.add(const Duration(days: 6));

    final response = await supabase
        .from('laporan')
        .select()
        .eq('id_cabang', uuidCabang) // now using UUID
        .gte('tanggal', firstDayOfWeek.toIso8601String())
        .lte('tanggal', lastDayOfWeek.toIso8601String());

    // Kelompokkan berdasarkan hari
    final grouped = <String, Map<String, dynamic>>{};
    for (var row in response) {
      final tanggal = DateTime.parse(row['tanggal']);
      final hari = _namaHariIndo(tanggal.weekday);

      if (!grouped.containsKey(hari)) {
        grouped[hari] = {'hari': hari, 'total_omset': 0, 'total_pengeluaran': 0};
      }

      grouped[hari]!['total_omset'] += (row['total_omset'] ?? 0).toInt();
      grouped[hari]!['total_pengeluaran'] += (row['total_pengeluaran'] ?? 0).toInt();
    }

    final orderedDays = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
    return orderedDays
        .where((hari) => grouped.containsKey(hari))
        .map((hari) => grouped[hari]!)
        .toList();
  }

  Widget _buildContent() {
    switch (_selectedIndex) {
      case 0:
        return FutureBuilder<Map<String, dynamic>>(
          future: _fetchProfile(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Gagal memuat profil: ${snapshot.error}'));
            }

            final profile = snapshot.data!;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Profil Akun',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 4,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 40,
                          backgroundImage: profile['foto_url'] != null
                              ? NetworkImage(profile['foto_url'])
                              : const AssetImage('assets/logobg.png')
                          as ImageProvider,
                        ),
                        const SizedBox(width: 20),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(profile['nama'] ?? '',
                                  style: const TextStyle(
                                      fontSize: 20, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 8),
                              Text('Jabatan: ${profile['jabatan'] ?? '-'}'),
                              Text('No. Telepon: ${profile['no_telepon'] ?? '-'}'),
                              Text('Alamat: ${profile['alamat'] ?? '-'}'),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () {
                            Navigator.pushNamed(context, '/edit-profil');
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        );
      case 1:
        return FutureBuilder<List<List<Map<String, dynamic>>>>(
          future: Future.wait<List<Map<String, dynamic>>>([
            _fetchLaporanMingguan(),
            _fetchOmzetPerMinggu(),
          ]),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text('Belum ada data laporan.'));
            } else {
              final laporanData = snapshot.data![0];
              final omzetData = snapshot.data![1];

              return SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildLaporanMingguan(laporanData),
                    _buildOmzetMingguan(omzetData),
                  ],
                ),
              );
            }
          },
        );

      case 2:
        return _buildMatoBoxList();
      case 3:
        return FutureBuilder<List<Map<String, dynamic>>>(
          future: _fetchRekapTransaksi(), // Panggil fungsi ambil data
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Terjadi kesalahan: ${snapshot.error}'));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text('Belum ada data transaksi.'));
            }

            final data = snapshot.data!;
            return _buildRekapTransaksi(data); // Panggil widget builder
          },
        );
      default:
        return const SizedBox(); // fallback jika _selectedIndex di luar 0–3
    }
  }

  String _formatRupiah(dynamic value) {
    if (value == null) return '0';
    return value.toString().replaceAllMapped(
        RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.');
  }

  String _namaHariIndo(int weekday) {
    switch (weekday) {
      case DateTime.monday:
        return 'Senin';
      case DateTime.tuesday:
        return 'Selasa';
      case DateTime.wednesday:
        return 'Rabu';
      case DateTime.thursday:
        return 'Kamis';
      case DateTime.friday:
        return 'Jumat';
      case DateTime.saturday:
        return 'Sabtu';
      case DateTime.sunday:
        return 'Minggu';
      default:
        return '';
    }
  }

  Widget _buildLaporanMingguan(List<Map<String, dynamic>> data) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Laporan Mingguan',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 160,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: data.length,
            separatorBuilder: (_, __) => const SizedBox(width: 16),
            itemBuilder: (context, index) {
              final item = data[index];
              final hari = item['hari'] ?? '-';
              final omset = item['total_omset'] ?? 0;
              final pengeluaran = item['total_pengeluaran'] ?? 0;

              return Container(
                width: 200,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(hari, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text("Omzet:", style: TextStyle(color: Colors.grey.shade600)),
                    Text("Rp ${_formatRupiah(omset)}", style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 8),
                    Text("Pengeluaran:", style: TextStyle(color: Colors.grey.shade600)),
                    Text("Rp ${_formatRupiah(pengeluaran)}", style: const TextStyle(fontSize: 16)),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildOmzetMingguan(List<Map<String, dynamic>> data) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 24),
        const Text(
          'Total HPP Mingguan',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 160,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: data.length,
            separatorBuilder: (_, __) => const SizedBox(width: 16),
            itemBuilder: (context, index) {
              final item = data[index];
              return Container(
                width: 180,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item['hari'] ?? '', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text("Total HPP:", style: TextStyle(color: Colors.grey.shade600)),
                    Text("Rp ${_formatRupiah(item['hpp'])}", style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  final supabase = Supabase.instance.client;

  // Fungsi ambil data pegawai dari Supabase berdasarkan id_cabang user login
  Future<List<Map<String, dynamic>>> _fetchOmzetPerMinggu() async {
    final supabase = Supabase.instance.client;
    final now = DateTime.now();
    final firstDay = now.subtract(Duration(days: now.weekday - 1));
    final lastDay = firstDay.add(const Duration(days: 6));

    final response = await supabase
        .from('omzet')
        .select()
        .eq('id_cabang', cabangIdKamu)
        .gte('tanggal', firstDay.toIso8601String())
        .lte('tanggal', lastDay.toIso8601String());

    final grouped = <String, int>{};

    for (final row in response) {
      final tanggal = DateTime.parse(row['tanggal']);
      final hari = DateFormat.EEEE('id_ID').format(tanggal);
      grouped[hari] = (grouped[hari] ?? 0) + ((row['total_hpp'] ?? 0) as num).toInt();
    }

    const daysOrder = [
      'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'
    ];

    return daysOrder
        .where((day) => grouped.containsKey(day))
        .map((day) => {'hari': day, 'hpp': grouped[day]!})
        .toList();
  }

  void _showDetailTransaksi(BuildContext context, String tanggal) async {
    final detail = await _getDetailTransaksi(tanggal);

    // Urutkan: pemasukan dulu (positif), lalu pengeluaran (negatif)
    detail.sort((a, b) {
      final jumlahA = a['jumlah'] as int;
      final jumlahB = b['jumlah'] as int;
      // Pemasukan positif -> tampil dulu, jadi sort menurun dari besar ke kecil
      return jumlahB.compareTo(jumlahA);
    });
    
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Detail Transaksi $tanggal'),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: detail.length,
              itemBuilder: (context, index) {
                final item = detail[index];
                final jenis = item['jenis_transaksi'];
                final jumlah = item['jumlah'];
                final formatted = NumberFormat.currency(locale: 'id', symbol: 'Rp ', decimalDigits: 0).format(jumlah.abs());
                final isPengeluaran = jumlah < 0;

                return ListTile(
                  leading: Icon(isPengeluaran ? Icons.remove_circle : Icons.add_circle, color: isPengeluaran ? Colors.red : Colors.green),
                  title: Text(jenis),
                  trailing: Text(formatted, style: TextStyle(fontSize: 22, color: isPengeluaran ? Colors.red : Colors.green)),
                );
              },
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup'))
          ],
        );
      },
    );
  }

// Fungsi dialog edit data pegawai
  void _showEditMatoDialog(Map<String, dynamic> item) {
    final TextEditingController namaController =
    TextEditingController(text: item['nama']);
    final TextEditingController jabatanController =
    TextEditingController(text: item['jabatan'] ?? '');
    final TextEditingController skorController = TextEditingController(
        text: (item['skor_mato'] ?? 0).toString());
    final int? skorMatoParsed = int.tryParse(skorController.text.trim());
    if (skorMatoParsed == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Skor harus berupa angka')),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Edit Pegawai: ${item['nama']}'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: namaController,
                  decoration: InputDecoration(labelText: 'Nama'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: jabatanController,
                  decoration: InputDecoration(labelText: 'Jabatan'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: skorController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: 'Skor Mato'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () async {
                final supabase = Supabase.instance.client;

                final String nama = namaController.text.trim();
                final String jabatan = jabatanController.text.trim();
                final int skorMato = int.tryParse(skorController.text.trim()) ?? 0;
                final String? id = item['id']; // pakai id dari item, bukan auth

                if (nama.isEmpty || jabatan.isEmpty || id == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Field tidak boleh kosong')),
                  );
                  return;
                }

                try {
                  await supabase
                      .from('profiles')
                      .update({
                    'nama': nama,
                    'jabatan': jabatan,
                    'skor_mato': skorMato,
                  })
                      .eq('id', id); // <== PENTING

                  Navigator.pop(context);
                  setState(() {}); // refresh
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Gagal update data: $e')),
                  );
                }
              },
              child: const Text('Simpan'),
            ),
          ],
        );
      },
    );
  }

// Fungsi dialog tambah pegawai (sementara placeholder)
  void _showAddMatoDialog() {
    showDialog(
      context: context,
      builder: (context) =>
          AlertDialog(
            title: const Text("Tambah Pegawai"),
            content: const Text("Form tambah pegawai belum dibuat."),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Tutup"),
              ),
            ],
          ),
    );
  }

  Widget _buildRekapTransaksi(List<Map<String, dynamic>> data) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Rekap Transaksi Harian',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 250,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: data.length,
            separatorBuilder: (context, index) => const SizedBox(width: 16),
            itemBuilder: (context, index) {
              final item = data[index];
              final tanggal = DateFormat('dd MMM yyyy')
                  .format(DateTime.parse(item['tanggal']));
              final total = item['total_transaksi'] ?? 0;
              final keterangan = item['keterangan'] ?? '-';

              return GestureDetector(
                onTap: () {
                  _showDetailTransaksi(context, item['tanggal']);
                  // Bisa juga tampilkan detail jika perlu
                },
                child: Container(
                  width: 240,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: const [
                      BoxShadow(color: Colors.black12, blurRadius: 4)
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tanggal,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text("Total: Rp ${_formatRupiah(total)}",
                          style: const TextStyle(fontSize: 14)),
                      const SizedBox(height: 8),
                      const Text('Keterangan:',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      Text(keterangan,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 13)),
                      const Spacer(),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit, size: 18),
                            onPressed: () =>
                                _editKeteranganTransaksi(context, item['tanggal']),
                          ),
                          const SizedBox(width: 8),
                          IconButton(
                            icon: const Icon(Icons.delete, size: 18),
                            onPressed: () =>
                                _deleteLaporan(context, item['tanggal']),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  void _showDetailDialog(BuildContext context, Map<String, dynamic> item) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Detail Laporan'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Tanggal: ${item['tanggal']}"),
              Text("Total Omzet: Rp ${_formatRupiah(item['total_omzet_bersih'] ?? 0)}"),
              const SizedBox(height: 8),
              const Text("Keterangan:", style: TextStyle(fontWeight: FontWeight.bold)),
              Text(item['keterangan'] ?? '-'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Tutup'),
            )
          ],
        );
      },
    );
  }

  Future<void> _editKeteranganTransaksi(BuildContext context, String tanggal) async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) return;

    // Ambil id_cabang dari profile
    final userProfile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = userProfile?['id_cabang'];
    if (idCabang == null) return;

    // Ambil salah satu transaksi di tanggal tsb untuk edit keterangannya
    final transaksi = await supabase
        .from('transaksi_harian')
        .select()
        .eq('id_cabang', idCabang)
        .eq('tanggal', tanggal) // format harus "yyyy-MM-dd"
        .limit(1)
        .maybeSingle();

    if (transaksi == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Detail tidak tersedia untuk data rekap.')),
      );
      return;
    }

    final TextEditingController keteranganController =
    TextEditingController(text: transaksi['keterangan'] ?? '');

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Keterangan'),
        content: TextField(
          controller: keteranganController,
          decoration: const InputDecoration(labelText: 'Keterangan baru'),
          maxLines: 3,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () async {
              await supabase
                  .from('transaksi_harian')
                  .update({'keterangan': keteranganController.text.trim()})
                  .eq('id', transaksi['id']);
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Keterangan berhasil diperbarui')),
              );
              setState(() {}); // Refresh tampilan
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteLaporan(BuildContext context, String tanggal) async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) return;

    final userProfile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = userProfile?['id_cabang'];
    if (idCabang == null) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Konfirmasi'),
        content: const Text('Yakin ingin menghapus semua transaksi pada tanggal ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      await supabase
          .from('transaksi_harian')
          .delete()
          .eq('id_cabang', idCabang)
          .eq('tanggal', tanggal);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Transaksi berhasil dihapus')),
      );

      setState(() {}); // refresh tampilan
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal menghapus: $e')),
      );
    }
  }


// Widget untuk menampilkan grid box pegawai dan tambah
  Widget _buildMatoBoxList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Mato Pegawai',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        FutureBuilder<List<Map<String, dynamic>>>(
          future: _fetchPegawaiFromSupabase(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            }

            final pegawai = snapshot.data ?? [];

            return LayoutBuilder(
              builder: (context, constraints) {
                int crossAxisCount = 2;
                if (constraints.maxWidth > 1000) {
                  crossAxisCount = 4;
                } else if (constraints.maxWidth > 700) {
                  crossAxisCount = 3;
                }

                return GridView.count(
                  crossAxisCount: crossAxisCount,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.5,
                  children: [
                    // Box Tambah
                    GestureDetector(
                      onTap: () => _showAddMatoDialog(),
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.red.shade200),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: const Center(
                          child: Icon(Icons.add, color: Colors.red, size: 40),
                        ),
                      ),
                    ),

                    // Box Pegawai
                    ...pegawai.map((item) {
                      final double progress = (item['skor_mato'] ?? 0) /
                          100.0;

                      return GestureDetector(
                        onTap: () => _showEditMatoDialog(item),
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: const [
                              BoxShadow(color: Colors.black12, blurRadius: 4)
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item['nama'] ?? '-',
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              if (item['jabatan'] != null && item['jabatan'].toString().isNotEmpty) ...[
                                const SizedBox(height: 4),
                                Text(
                                  'Jabatan: ${item['jabatan']}',
                                  style: const TextStyle(fontSize: 14, color: Colors.black87),
                                ),
                              ],
                              const SizedBox(height: 8),
                              // LinearProgressIndicator(value: progress), ← ini dihapus
                              Text('Poin Mato: ${item['skor_mato'] ?? 0}'),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ],
                );
              },
            );
          },
        ),
      ],
    );
  }

  void _showInputOmzetDialog() {
    String omzet = '';

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Input Omzet Hari Ini'),
          content: TextField(
            decoration: const InputDecoration(labelText: 'Total Omzet'),
            keyboardType: TextInputType.number,
            onChanged: (val) => omzet = val,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                      content: Text('Omzet berhasil disimpan: Rp $omzet')),
                );
                // Logika DB
              },
              child: const Text('Simpan'),
            ),
          ],
        );
      },
    );
  }
}