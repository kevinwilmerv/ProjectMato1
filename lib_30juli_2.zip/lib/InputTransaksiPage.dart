import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'package:intl/intl.dart';

class InputTransaksiPage extends StatefulWidget {
  final String cabangId;
  const InputTransaksiPage({Key? key, required this.cabangId}) : super(key: key);

  @override
  State<InputTransaksiPage> createState() => _InputTransaksiPageState();
}

class _InputTransaksiPageState extends State<InputTransaksiPage> {
  final TextEditingController _jenisBaruController = TextEditingController();
  final manualLabelController = TextEditingController();
  final SupabaseClient supabase = Supabase.instance.client;
  final Map<String, TextEditingController> _controllerMap = {};
  final Map<String, TextEditingController> _pengeluaranControllerMap = {};
  final Map<String, TextEditingController> namaLainnyaControllerMap = {};
  final Map<String, String> manualPengeluaranLabel = {};
  final Map<String, String> manualPemasukanLabel = {};
  final Map<String, String> selectedKategoriPemasukan = {};
  final Map<String, String?> selectedSubkategoriPemasukan = {};
  final Map<String, String> selectedKategoriPengeluaran = {};
  final currencyFormat = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

  DateTime _selectedDate = DateTime.now();

  int get _totalPemasukan => _controllerMap.values
      .map((e) => int.tryParse(e.text.replaceAll('.', '')) ?? 0)
      .fold(0, (a, b) => a + b);

  int get _totalPengeluaran => _pengeluaranControllerMap.values
      .map((e) => int.tryParse(e.text.replaceAll('.', '')) ?? 0)
      .fold(0, (a, b) => a + b);

  int get _labaBersih => _totalPemasukan - _totalPengeluaran;

  final Map<String, List<String>> kategoriPemasukan = {
    'Cash': [],
    'Debit': [],
    'Kredit': [],
    'E-Wallet': ['Gopay', 'OVO', 'ShopeePay', 'Lainnya'],
    'Pesanan Online': ['GoFood', 'GrabFood', 'ShopeeFood', 'Lainnya'],
    'Pajak': [],
  };

  final List<String> kategoriPengeluaran = [
    'Makan Siang Karyawan',
    'Iuran Sampah & Honorer',
    'Bensin dan Servis Kendaraan',
    'Listrik, Telepon & PAM',
    'Lainnya',
  ];

  @override
  void initState() {
    super.initState();
    _loadFromPrefs();

    // Tambah input default agar dropdown langsung muncul
    _controllerMap['Pemasukan #1'] = TextEditingController();
    selectedKategoriPemasukan['Pemasukan #1'] = kategoriPemasukan.keys.first;
    selectedSubkategoriPemasukan['Pemasukan #1'] = null;

    _pengeluaranControllerMap['Pengeluaran #1'] = TextEditingController();
    selectedKategoriPengeluaran['Pengeluaran #1'] = kategoriPengeluaran.first;
  }


  Future<void> _loadFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final key = _generatePrefsKey();
    final jsonString = prefs.getString(key);
    if (jsonString != null) {
      final Map<String, dynamic> jsonData = json.decode(jsonString);
      jsonData.forEach((jenis, jumlah) {
        _controllerMap[jenis] = TextEditingController(text: jumlah.toString());
      });
      setState(() {});
    }
  }

  Future<void> _saveToPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final data = _controllerMap.map((key, controller) => MapEntry(key, controller.text));
    final jsonString = json.encode(data);
    await prefs.setString(_generatePrefsKey(), jsonString);
  }

  String _generatePrefsKey() {
    final formattedDate = DateFormat('yyyy-MM-dd').format(_selectedDate);
    return 'transaksi_${widget.cabangId}_$formattedDate';
  }

  final Map<String, List<Map<String, TextEditingController>>> _data = {};

  Future<void> _simpanKeSupabase() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('User belum login')),
      );
      return;
    }

    try {
      final userProfile = await supabase
          .from('profiles')
          .select('id_cabang')
          .eq('id', user.id)
          .maybeSingle();

      if (userProfile == null || userProfile['id_cabang'] == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ID cabang tidak ditemukan')),
        );
        return;
      }

      final idCabang = userProfile['id_cabang'];

      final semuaData = [
        ..._controllerMap.entries.map((e) {
          final jenis = e.key;
          final kategori = selectedKategoriPemasukan[jenis] ?? 'Tidak diketahui';
          final subkategori = selectedSubkategoriPemasukan[jenis];
          final isLainnya = subkategori == 'Lainnya';
          final customLabel = isLainnya ? manualPemasukanLabel[jenis] : null;

          return {
            'id': const Uuid().v4(),
            'tanggal': DateFormat('yyyy-MM-dd').format(_selectedDate),
            'id_cabang': idCabang,
            'jenis_transaksi': 'pemasukan',
            'jumlah': int.tryParse(e.value.text.replaceAll('.', '')) ?? 0,
            'kategori': kategori,
            'sub_kategori': isLainnya ? null : subkategori,
            'custom_label': customLabel ?? '',
            'created_at': DateTime.now().toIso8601String(),
            'created_by': user.id,
          };
        }),

        ..._pengeluaranControllerMap.entries.map((e) {
          final jenis = e.key;
          final kategori = selectedKategoriPengeluaran[jenis] ?? 'Tidak diketahui';
          final isLainnya = kategori == 'Lainnya';
          final customLabel = isLainnya ? manualPengeluaranLabel[jenis] : null;
          final jumlah = int.tryParse(e.value.text.replaceAll('.', '')) ?? 0;

          return {
            'id': const Uuid().v4(),
            'tanggal': DateFormat('yyyy-MM-dd').format(_selectedDate),
            'id_cabang': idCabang,
            'jenis_transaksi': 'pengeluaran',
            'jumlah': (jumlah ?? 0).toInt(),
            'kategori': kategori,
            'sub_kategori': null,
            'custom_label': customLabel ?? '',
            'created_at': DateTime.now().toIso8601String(),
            'created_by': user.id,
          };
        }),
      ];

      if (semuaData.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tidak ada data untuk disimpan')),
        );
        return;
      }

      await supabase.from('transaksi_harian').insert(semuaData);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Data berhasil disimpan')),
      );

      setState(() {
        _controllerMap.clear();
        _pengeluaranControllerMap.clear();
      });
    } catch (e) {
      print('Data gagal disimpan: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal simpan: $e')),
      );
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }


  void _hapusJenis(String jenis) {
    setState(() {
      _controllerMap.remove(jenis);
    });
  }

  Widget _buildInputRow(MapEntry<String, TextEditingController> entry, {required bool isPengeluaran}) {
    final jenis = entry.key;
    final controller = entry.value;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(jenis)),
              IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: () {
                  setState(() {
                    if (isPengeluaran) {
                      _pengeluaranControllerMap.remove(jenis);
                      selectedKategoriPengeluaran.remove(jenis);
                    } else {
                      _controllerMap.remove(jenis);
                      selectedKategoriPemasukan.remove(jenis);
                      selectedSubkategoriPemasukan.remove(jenis);
                    }
                  });
                },
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Kategori & Subkategori Pemasukan
          if (!isPengeluaran) ...[
            DropdownButtonFormField<String>(
              value: selectedKategoriPemasukan[jenis],
              items: kategoriPemasukan.keys
                  .map((kat) => DropdownMenuItem(value: kat, child: Text(kat)))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  selectedKategoriPemasukan[jenis] = value!;
                  selectedSubkategoriPemasukan[jenis] = null;
                });
              },
              decoration: const InputDecoration(labelText: 'Kategori'),
            ),

            if ((kategoriPemasukan[selectedKategoriPemasukan[jenis]] ?? []).isNotEmpty)
              selectedSubkategoriPemasukan[jenis] == 'Lainnya'
                  ? TextField(
                decoration: const InputDecoration(labelText: 'Isi nama lainnya'),
                onChanged: (val) {
                  setState(() {
                    manualPemasukanLabel[jenis] = val;
                  });
                },
              )
                  : DropdownButtonFormField<String>(
                value: selectedSubkategoriPemasukan[jenis],
                items: kategoriPemasukan[selectedKategoriPemasukan[jenis]]!
                    .map((sub) => DropdownMenuItem(value: sub, child: Text(sub)))
                    .toList(),
                onChanged: (val) {
                  setState(() {
                    selectedSubkategoriPemasukan[jenis] = val!;
                  });
                },
                decoration: const InputDecoration(labelText: 'Subkategori'),
              ),
          ]

          // Kategori Pengeluaran
          else ...[
            DropdownButtonFormField<String>(
              value: selectedKategoriPengeluaran[jenis],
              items: kategoriPengeluaran
                  .map((kat) => DropdownMenuItem(value: kat, child: Text(kat)))
                  .toList(),
              onChanged: (val) {
                setState(() {
                  selectedKategoriPengeluaran[jenis] = val!;
                });
              },
              decoration: const InputDecoration(labelText: 'Kategori Pengeluaran'),
            ),

            if (selectedKategoriPengeluaran[jenis] == 'Lainnya') ...[
              TextField(
                decoration: const InputDecoration(labelText: 'Isi nama lainnya'),
                onChanged: (val) {
                  setState(() {
                    manualPengeluaranLabel[jenis] = val;
                  });
                },
              ),
            ],
          ],

          const SizedBox(height: 8),

          // Input Jumlah
          TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              hintText: 'Jumlah',
              border: OutlineInputBorder(),
            ),
            onChanged: (val) {
              setState(() {}); // Trigger subtotal dan laba bersih update
            },
          ),
        ],
      ),
    );
  }

  final TextEditingController _jenisPengeluaranBaruController = TextEditingController();

  String _formatCurrency(dynamic value) {
    final int safeValue;
    if (value == null) {
      safeValue = 0;
    } else if (value is double) {
      safeValue = value.toInt();
    } else if (value is int) {
      safeValue = value;
    } else {
      safeValue = int.tryParse(value.toString()) ?? 0;
    }

    return currencyFormat.format(safeValue);
  }

  @override
  Widget build(BuildContext context) {
    final formattedDate = DateFormat('dd MMMM yyyy').format(_selectedDate);

    return Scaffold(
      appBar: AppBar(title: const Text('Input Transaksi Harian')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            // Tanggal Picker (tidak diubah)
            Row(
              children: [
                const Text('Tanggal:', style: TextStyle(fontSize: 16)),
                const SizedBox(width: 12),
                Text(formattedDate, style: const TextStyle(fontWeight: FontWeight.bold)),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.calendar_today),
                  onPressed: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: _selectedDate,
                      firstDate: DateTime(2020),
                      lastDate: DateTime.now(),
                    );
                    if (picked != null) {
                      setState(() {
                        _selectedDate = picked;
                        _loadFromPrefs();
                      });
                    }
                  },
                ),
              ],
            ),

            const SizedBox(height: 24),
            const Text('Pemasukan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),

            for (var entry in _controllerMap.entries)
              _buildInputRow(entry, isPengeluaran: false),

            // Tombol tambah pemasukan
            TextButton.icon(
              onPressed: () {
                final jenis = 'Pemasukan #${_controllerMap.length + 1}';
                setState(() {
                  final controller = TextEditingController();
                  controller.addListener(() => setState(() {}));
                  _controllerMap[jenis] = TextEditingController();
                  selectedKategoriPemasukan[jenis] = kategoriPemasukan.keys.first;
                  selectedSubkategoriPemasukan[jenis] = null;
                  namaLainnyaControllerMap[jenis] = TextEditingController();
                });
              },
              icon: const Icon(Icons.add),
              label: const Text("Tambah Pemasukan"),
            ),

            Text('Subtotal: ${_formatCurrency(_totalPemasukan)}'),

            const SizedBox(height: 24),
            const Text('Pengeluaran', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),

            for (var entry in _pengeluaranControllerMap.entries)
              _buildInputRow(entry, isPengeluaran: true),

            TextButton.icon(
              onPressed: () {
                final jenis = 'Pengeluaran #${_pengeluaranControllerMap.length + 1}';
                setState(() {
                  final controller = TextEditingController();
                  controller.addListener(() => setState(() {}));
                  _pengeluaranControllerMap[jenis] = TextEditingController();
                  selectedKategoriPengeluaran[jenis] = kategoriPengeluaran.first;
                });
              },
              icon: const Icon(Icons.add),
              label: const Text("Tambah Pengeluaran"),
            ),

            Text('Subtotal: ${_formatCurrency(_totalPengeluaran)}'),

            const SizedBox(height: 24),
            Text('Laba Bersih: ${_formatCurrency(_labaBersih)}'),

            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () async {
                await _saveToPrefs();
                await _simpanKeSupabase();
              },
              child: const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }
  @override
  void dispose() {
    for (var c in _controllerMap.values) {
      c.dispose();
    }
    for (var c in _pengeluaranControllerMap.values) {
      c.dispose();
    }
    _jenisBaruController.dispose();
    _jenisPengeluaranBaruController.dispose();
    super.dispose();
  }
}
