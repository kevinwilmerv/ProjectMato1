import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';

class LogPage extends StatelessWidget {
  const LogPage({super.key});

  Future<List<Map<String, dynamic>>> fetchLogs() async {
    final supabase = Supabase.instance.client;
    final response = await supabase
        .from('log_activity')
        .select()
        .order('waktu', ascending: false);
    return List<Map<String, dynamic>>.from(response);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Log Aktivitas')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: fetchLogs(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Terjadi error: ${snapshot.error}'));
          }

          final logs = snapshot.data!;
          return ListView.builder(
            itemCount: logs.length,
            itemBuilder: (context, index) {
              final log = logs[index];
              return ListTile(
                title: Text(log['aktivitas']),
                subtitle: Text('Cabang: ${log['id_cabang']} • Role: ${log['role']}'),
                trailing: Text(
                  DateFormat('dd MMM yyyy, HH:mm').format(DateTime.parse(log['waktu'])),
                  style: const TextStyle(fontSize: 12),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
