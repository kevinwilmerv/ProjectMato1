import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';

class DashboardAdmin extends StatefulWidget {
  const DashboardAdmin({super.key});

  @override
  State<DashboardAdmin> createState() => _DashboardAdminState();
}

class _DashboardAdminState extends State<DashboardAdmin> {
  int _selectedIndex = 0;
  final _searchController = TextEditingController();
  List<dynamic> _allCabang = [];
  List<dynamic> _filteredCabang = [];

  @override
  void initState() {
    super.initState();
    fetchCabang();
    _searchController.addListener(_onSearchChanged);
  }

  void _onTabSelected(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Future<List<Map<String, dynamic>>> fetchPegawaiDetail(String idCabang) async {
    final supabase = Supabase.instance.client;

    final response = await supabase
        .from('rekap_mingguan')
        .select()
        .eq('id_cabang', idCabang);

    return List<Map<String, dynamic>>.from(response);
  }

  Future<void> fetchCabang() async {
    final response = await Supabase.instance.client
        .from('cabang')
        .select();

    setState(() {
      _allCabang = response;
      _filteredCabang = response;
    });
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredCabang = _allCabang.where((cabang) {
        final nama = cabang['nama_cabang'].toLowerCase();
        final lokasi = cabang['lokasi'].toLowerCase();
        return nama.contains(query) || lokasi.contains(query);
      }).toList();
    });
  }

  final List<Widget> _pages = [
    const Center(child: Text("Dashboard Page")),
    const Center(child: Text("Laporan Page")),
    const Center(child: Text("Mato Page")),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Builder(
                  builder: (context) => IconButton(
                    icon: const Icon(Icons.menu, size: 34, color: Colors.black),
                    onPressed: () => Scaffold.of(context).openDrawer(),
                  ),
                ),
                const SizedBox(width: 16),
                Row(
                  children: [
                    Image.asset('assets/logobg.png', height: 85),
                    const SizedBox(width: 10),
                    RichText(
                      text: const TextSpan(
                        children: [
                          TextSpan(text: 'SIMPANG ', style: TextStyle(color: Colors.black, fontSize: 30)),
                          TextSpan(text: 'RAYA', style: TextStyle(color: Colors.red, fontSize: 30, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: const [
                    Text('ADMIN PUSAT', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black)),
                    Text('OWNER', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFFFD1D1), Colors.white],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Admin Pusat', style: TextStyle(color: Colors.black, fontSize: 20)),
                  SizedBox(height: 8),
                  Text('pusatsimpraya@example.com', style: TextStyle(color: Colors.black54)),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              onTap: () {
                Navigator.pop(context);
                Future.delayed(const Duration(milliseconds: 300), () {
                  Navigator.of(context).pushReplacementNamed('/login');
                });
              },
            ),
          ],
        ),
      ),
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFD1D1), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            const SizedBox(height: 150),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _navButton('Dashboard', Iconsax.category, 0),
                  const SizedBox(width: 15),
                  _navButton('Laporan', Iconsax.chart_square, 1),
                  const SizedBox(width: 15),
                  _navButton('Mato', Iconsax.chart, 2),
                  const SizedBox(width: 15),
                  _navButton('Cabang', Iconsax.house, 3),
                ],
              ),
            ),
            const SizedBox(height: 30),
            Expanded(child: _selectedIndex == 3 ? _buildCabangPage() : _pages[_selectedIndex]),
          ],
        ),
      ),
    );
  }

  Widget _navButton(String label, IconData icon, int index) {
    final bool isActive = _selectedIndex == index;
    return InkWell(
      onTap: () => _onTabSelected(index),
      borderRadius: BorderRadius.circular(40),
      child: Container(
        width: 180,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: isActive ? const Color(0xFFFFC5CC) : Colors.white,
          borderRadius: BorderRadius.circular(40),
          boxShadow: const [
            BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(2, 4)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.black),
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16, color: Colors.black)),
          ],
        ),
      ),
    );
  }

  Widget _buildCabangPage() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          child: Center(
            child: SizedBox(
              width: 1240,
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Cari cabang...',
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Scrollbar(
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: Column(
                  children: [
                    Wrap(
                      spacing: 16,
                      runSpacing: 16,
                      children: _filteredCabang
                          .map((cabang) => _buildCabangCard(cabang))
                          .toList(),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _showCabangDetailPopup(BuildContext context, dynamic cabang) async {
    final supabase = Supabase.instance.client;
    final profiles = await supabase.from('profiles').select().eq('id_cabang', cabang['id_cabang']);
    final jumlahPegawai = profiles.length;
    final totalOmzet = await fetchTotalOmzetHarian(cabang['id_cabang']);
    final formatter = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: SizedBox(
            width: MediaQuery.of(context).size.width * 0.9,
            height: MediaQuery.of(context).size.height * 0.85,
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Detail Cabang - ${cabang['nama_cabang']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('ID Cabang: ${cabang['id_cabang']}'),
                  Text('Lokasi: ${cabang['lokasi']}'),
                  const SizedBox(height: 8),
                  Text('Omzet Hari Ini: ${formatter.format(totalOmzet)}'),
                  const SizedBox(height: 8),
                  Text('Jumlah Pegawai: $jumlahPegawai'),
                  const SizedBox(height: 16),
                  const Text('Daftar Pegawai Mingguan', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Divider(height: 1),
                  const SizedBox(height: 12),
                  Expanded(
                    child: FutureBuilder<List<Map<String, dynamic>>>(
                      future: fetchPegawaiDetail(cabang['id_cabang']),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return const Center(child: CircularProgressIndicator());
                        } else if (snapshot.hasError) {
                          return Center(child: Text('Gagal memuat data: ${snapshot.error}'));
                        }
                        final data = snapshot.data ?? [];
                        if (data.isEmpty) {
                          return const Center(child: Text('Belum ada data pegawai.'));
                        }
                        return Scrollbar(
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: DataTable(
                              headingRowColor: MaterialStateProperty.all(Colors.grey[200]),
                              columns: const [
                                DataColumn(label: Text('No')),
                                DataColumn(label: Text('Nama')),
                                DataColumn(label: Text('Jabatan')),
                                DataColumn(label: Text('Mata')),
                                DataColumn(label: Text('Nilai/Mata')),
                                DataColumn(label: Text('Pendapatan')),
                                DataColumn(label: Text('Pinjaman')),
                                DataColumn(label: Text('Bon Makan')),
                                DataColumn(label: Text('Bon Gudang')),
                                DataColumn(label: Text('Absen')),
                                DataColumn(label: Text('Pot Absen')),
                                DataColumn(label: Text('Total')),
                                DataColumn(label: Text('Hasil')),
                              ],
                              rows: data.asMap().entries.map((entry) {
                                final index = entry.key + 1;
                                final pegawai = entry.value;
                                return DataRow(cells: [
                                  DataCell(Text('$index')),
                                  DataCell(Text(pegawai['nama'] ?? '-')),
                                  DataCell(Text(pegawai['jabatan'] ?? '-')),
                                  DataCell(Text('${pegawai['mata'] ?? '-'}')),
                                  DataCell(Text('${pegawai['nilai_per_mata'] ?? '-'}')),
                                  DataCell(Text('${pegawai['pendapatan'] ?? '-'}')),
                                  DataCell(Text('${pegawai['pinjaman'] ?? '-'}')),
                                  DataCell(Text('${pegawai['bon_makan'] ?? '-'}')),
                                  DataCell(Text('${pegawai['bon_gudang'] ?? '-'}')),
                                  DataCell(Text('${pegawai['absen'] ?? '-'}')),
                                  DataCell(Text('${pegawai['pot_absen'] ?? '-'}')),
                                  DataCell(Text('${pegawai['total_mingguan'] ?? '-'}')),
                                  DataCell(Text('${pegawai['hasil'] ?? '-'}')),
                                ]);
                              }).toList(),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 12),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      child: const Text('Tutup'),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<num> fetchTotalOmzetHarian(String idCabang) async {
    final supabase = Supabase.instance.client;
    final today = DateTime.now();
    final formattedDate = DateFormat('yyyy-MM-dd').format(today);

    final response = await supabase
        .from('omzet')
        .select('total_hpp')
        .eq('id_cabang', idCabang)
        .eq('tanggal', formattedDate);

    final List data = response;
    final total = data.fold<num>(0, (sum, item) => sum + (item['total_hpp'] ?? 0));
    return total;
  }

  Widget _buildCabangCard(dynamic cabang) {
    return Container(
      width: 300,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(cabang['id_cabang'] ?? '', style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 4),
          Text(cabang['nama_cabang'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          Text(cabang['lokasi'] ?? '', style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 12),
          Text(cabang['omzet_harian'] ?? 'Rp. 0', style: const TextStyle(color: Colors.orange, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => _showCabangDetailPopup(context, cabang),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green[100],
                foregroundColor: Colors.green[800],
                padding: const EdgeInsets.symmetric(vertical: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: 0,
              ),
              child: const Text('Detail', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }
}
