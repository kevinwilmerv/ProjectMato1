import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'pages/login_page.dart';
import 'pages/register_page.dart';
import 'dashboard/dashboard_admin.dart';
import 'dashboard/dashboard_cabang.dart';
import 'dashboard/dashboard_staff.dart';
import 'pages/omzet_page.dart';
import 'InputOmzetPage.dart';
import 'InputMatoPermata.dart';
import 'pages/edit_profil_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url:
    'https://bgkevrxaodhihleiqqqg.supabase.co',
    anonKey:
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJna2V2cnhhb2RoaWhsZWlxcXFnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTI2MjU0NTcsImV4cCI6MjA2ODIwMTQ1N30.hjsXcsRwUqfUtLqSCRUaHnJ_ItNygDOHrXDx8U8DtMo', // Ganti dengan anon key kamu
  );

  runApp(const SimpangRayaApp());
}

class SimpangRayaApp extends StatelessWidget {
  const SimpangRayaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sistem Keuangan Simpang Raya',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Poppins',
        colorSchemeSeed: Colors.green,
      ),
      initialRoute: '/login',
      routes: {
        '/': (context) => const LoginPage(),
        '/login': (context) => const LoginPage(),
        '/register': (context) => const RegisterPage(),
        '/dashboard-admin': (context) => const DashboardAdmin(),
        '/dashboard-cabang': (context) {
          final args = ModalRoute.of(context)!.settings.arguments as Map<String, String>;
          return DashboardCabang(
            idCabang: args['idCabang']!,
            namaCabang: args['namaCabang']!,
          );
        },
        '/edit-profil': (context) => const EditProfilPage(),
        '/dashboard_staff': (context) => const DashboardStaff(),
        '/omzet': (context) => const OmzetPage(),
        '/input-permata': (context) {
          final cabangId = ModalRoute.of(context)?.settings.arguments as String;
          return InputMatoPermata(cabangId: cabangId);
        },
        '/input-omzet': (context) {
          // Simulasi pengambilan cabangId, misalnya dari Supabase user metadata
          final cabangId = Supabase.instance.client.auth.currentUser?.userMetadata?['cabang_id'] ?? 'cabang-default';
          return InputOmzetPage(cabangId: cabangId);
        },
      },
    );
  }
}
