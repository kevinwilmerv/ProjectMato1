import 'package:flutter/material.dart';

class InputOmzetPage extends StatefulWidget {
  final String cabangId;

  const InputOmzetPage({Key? key, required this.cabangId}) : super(key: key);

  @override
  State<InputOmzetPage> createState() => _InputOmzetPageState();
}

class _InputOmzetPageState extends State<InputOmzetPage> {
  final List<String> kategori = [
    'Bahan Sayur',
    'Bahan Baku',
    'Bumbu & Bahan Baku Pelengkap',
    'Bumbu Sunda & Bahan Bakar',
    'Buah & Minuman Botol',
    'Kelengkapan Jus',
    'Pelengkapan',
    'Peralatan',
    'Konsinyasi',
  ];

  /// Menyimpan list barang (dengan controller) untuk setiap kategori
  final Map<String, List<Map<String, TextEditingController>>> _data = {};

  @override
  void initState() {
    super.initState();
    for (var k in kategori) {
      _data[k] = [];
    }
  }

  void _tambahItem(String kategori) {
    setState(() {
      _data[kategori]!.add({
        'id': TextEditingController(),
        'nama': TextEditingController(),
        'jumlah': TextEditingController(),
        'satuan': TextEditingController(),
        'harga': TextEditingController(),
      });
    });
  }

  void _hapusItem(String kategori, int index) {
    setState(() {
      _data[kategori]![index].forEach((_, controller) => controller.dispose());
      _data[kategori]!.removeAt(index);
    });
  }

  Widget _buildBarangRow(String kategori, int index) {
    final item = _data[kategori]![index];

    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: item['id'],
                decoration: const InputDecoration(labelText: 'ID Barang'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextFormField(
                controller: item['nama'],
                decoration: const InputDecoration(labelText: 'Nama Barang'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: item['jumlah'],
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Jumlah'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextFormField(
                controller: item['satuan'],
                decoration: const InputDecoration(labelText: 'Satuan'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextFormField(
                controller: item['harga'],
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Harga Beli'),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => _hapusItem(kategori, index),
            ),
          ],
        ),
        const Divider(),
      ],
    );
  }

  void _simpanSemuaData() {
    final hasil = {};

    for (var kat in kategori) {
      hasil[kat] = _data[kat]!.map((item) {
        return {
          'id': item['id']!.text,
          'nama': item['nama']!.text,
          'jumlah': item['jumlah']!.text,
          'satuan': item['satuan']!.text,
          'harga': item['harga']!.text,
        };
      }).toList();
    }

    print('Data disiapkan untuk disimpan:');
    print(hasil);

    // TODO: kirim ke Supabase
  }

  @override
  void dispose() {
    for (var list in _data.values) {
      for (var item in list) {
        item.forEach((_, controller) => controller.dispose());
      }
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Beban Pokok Pengeluaran - ${widget.cabangId}')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: kategori.map((kat) {
            return ExpansionTile(
              title: Text(kat, style: const TextStyle(fontWeight: FontWeight.bold)),
              children: [
                ...List.generate(
                  _data[kat]!.length,
                      (index) => _buildBarangRow(kat, index),
                ),
                TextButton.icon(
                  onPressed: () => _tambahItem(kat),
                  icon: const Icon(Icons.add),
                  label: const Text('Tambah Barang'),
                ),
              ],
            );
          }).toList(),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: ElevatedButton.icon(
          onPressed: _simpanSemuaData,
          icon: const Icon(Icons.save),
          label: const Text('Simpan Semua'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red,
            minimumSize: const Size.fromHeight(50),
          ),
        ),
      ),
    );
  }
}
