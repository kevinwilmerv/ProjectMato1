import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';


class LogService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  static Future<void> logActivity({
    required String aktivitas,
    required String idCabang,
    required String role,
  }) async {
    final user = _supabase.auth.currentUser;

    if (user == null) {
      print('❌ Tidak ada user login');
      return;
    }

    try {
      await _supabase.from('log_activity').insert({
        'id_user': user.id,
        'id_cabang': idCabang,
        'role': role,
        'aktivitas': aktivitas,
      });
      print('✅ Log berhasil disimpan: $aktivitas');
    } catch (e) {
      print('❌ Gagal menyimpan log: $e');
    }
  }
}
