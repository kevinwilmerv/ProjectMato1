import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class InputLabaBersihPage extends StatefulWidget {
  final String idCabang;
  final DateTime tanggal;

  const InputLabaBersihPage({
    super.key,
    required this.idCabang,
    required this.tanggal,
  });

  @override
  State<InputLabaBersihPage> createState() => _InputLabaBersihPageState();
}

class _InputLabaBersihPageState extends State<InputLabaBersihPage> {
  int totalPemasukan = 0;
  int totalPengeluaran = 0;
  int totalHPP = 0;

  final penyusutanController = TextEditingController();
  final servisKantorController = TextEditingController();

  int get labaKotor => totalPemasukan - totalHPP;
  int get labaSebelumBiayaTetap => labaKotor - totalPengeluaran;
  int get labaBersih => labaSebelumBiayaTetap - biayaTetap;

  int get biayaTetap {
    final sewa = int.tryParse(penyusutanController.text) ?? 0;
    final servis = int.tryParse(servisKantorController.text) ?? 0;
    return sewa + servis;
  }

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  Future<void> _fetchData() async {
    // Ganti nanti dengan fetch dari Supabase
    setState(() {
      totalPemasukan = 12000000;
      totalPengeluaran = 3500000;
      totalHPP = 4500000;
    });
  }

  String _format(int value) {
    return NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0).format(value);
  }

  @override
  Widget build(BuildContext context) {
    final tanggalFormatted = DateFormat('dd MMMM yyyy', 'id_ID').format(widget.tanggal);

    return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent, // transparan
          elevation: 0,
          title: const Text(
            'Input Transaksi Harian',
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
          ),
          iconTheme: const IconThemeData(color: Colors.black),
        ),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFC1CC), Colors.white],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, kToolbarHeight + 24, 24, 24),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Tanggal: $tanggalFormatted", style: const TextStyle(fontSize: 18)),
                const SizedBox(height: 16),
                _infoCard("Net Sales (Pemasukan)", _format(totalPemasukan), Icons.trending_up),
                _infoCard("Beban Pokok Penjualan (HPP)", _format(totalHPP), Icons.shopping_cart),
                _infoCard("Laba Kotor", _format(labaKotor), Icons.bar_chart),
                _infoCard("Beban Usaha", _format(totalPengeluaran), Icons.money_off),
                const SizedBox(height: 16),
                const Divider(),
                const SizedBox(height: 12),
                const Text("Biaya Tetap Lainnya", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                const SizedBox(height: 12),
                _buildInputField("Sewa & Penyusutan", penyusutanController),
                const SizedBox(height: 12),
                _buildInputField("Servis Kantor", servisKantorController),
                const SizedBox(height: 24),
                _infoCard("Laba Bersih", _format(labaBersih), Icons.star, highlight: true),
                const SizedBox(height: 24),
                Center(
                  child: ElevatedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.save),
                    label: const Text("Simpan Laporan"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      minimumSize: const Size.fromHeight(50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoCard(String label, String value, IconData icon, {bool highlight = false}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: highlight ? Colors.green.shade50 : Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(children: [
            Icon(icon, color: Colors.black),
            const SizedBox(width: 12),
            Text(label, style: const TextStyle(fontSize: 16)),
          ]),
          Text(value, style: TextStyle(fontWeight: FontWeight.bold, color: highlight ? Colors.green : Colors.black)),
        ],
      ),
    );
  }

  Widget _buildInputField(String label, TextEditingController controller) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        prefixIcon: const Icon(Icons.attach_money),
      ),
      onChanged: (_) => setState(() {}),
    );
  }
}
