import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:uuid/uuid.dart';

import 'dart:io' as io;

class EditProfilPage extends StatefulWidget {
  const EditProfilPage({super.key});

  @override
  State<EditProfilPage> createState() => _EditProfilPageState();
}

class _EditProfilPageState extends State<EditProfilPage> {
  final supabase = Supabase.instance.client;

  io.File? _localImage; // hanya untuk platform
  Uint8List? _webImageBytes;
  String? _webImageName;
  String? fotoUrl;

  final TextEditingController namaController = TextEditingController();
  final TextEditingController alamatController = TextEditingController();
  final TextEditingController noTeleponController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    final data = await supabase
        .from('profiles')
        .select()
        .eq('id', user.id)
        .maybeSingle();

    if (data != null) {
      namaController.text = data['nama'] ?? '';
      alamatController.text = data['alamat'] ?? '';
      noTeleponController.text = data['no_telepon'] ?? '';
      fotoUrl = data['foto_url'];
      setState(() {});
    }
  }

  Future<void> _pickImage() async {
    if (kIsWeb) {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.image,
        withData: true,
      );
      if (result != null && result.files.single.bytes != null) {
        setState(() {
          _webImageBytes = result.files.single.bytes;
          _webImageName = result.files.single.name;
        });
      }
    } else {
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (picked != null) {
        setState(() {
          _localImage = io.File(picked.path);
        });
      }
    }
  }

  Future<String?> _uploadImage() async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return null;

    final uuid = const Uuid().v4();
    late final String path;
    late final String publicUrl;

    if (kIsWeb && _webImageBytes != null && _webImageName != null) {
      path = 'public/$uuid-${_webImageName!}';
      await supabase.storage
          .from('profile_pictures')
          .uploadBinary(path, _webImageBytes!);
      publicUrl = supabase.storage.from('profile_pictures').getPublicUrl(path);
      return publicUrl;
    }

    if (!kIsWeb && _localImage != null) {
      final ext = _localImage!.path.split('.').last;
      path = 'public/$uuid.$ext';
      final fileBytes = await _localImage!.readAsBytes();
      await supabase.storage
          .from('profile_pictures')
          .uploadBinary(path, fileBytes); // ✅ aman
      publicUrl = supabase.storage.from('profile_pictures').getPublicUrl(path);
      return publicUrl;
    }

    return fotoUrl;
  }

  Future<void> _saveProfile() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    final newFotoUrl = await _uploadImage();

    await supabase.from('profiles').update({
      'nama': namaController.text.trim(),
      'alamat': alamatController.text.trim(),
      'no_telepon': noTeleponController.text.trim(),
      'foto_url': newFotoUrl,
    }).eq('id', user.id);

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Profil berhasil diperbarui")),
      );
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final profileImage = kIsWeb
        ? (_webImageBytes != null
        ? MemoryImage(_webImageBytes!)
        : (fotoUrl != null
        ? NetworkImage(fotoUrl!)
        : const AssetImage('assets/default_profile.png')))
        : (_localImage != null
        ? FileImage(_localImage!)
        : (fotoUrl != null
        ? NetworkImage(fotoUrl!)
        : const AssetImage('assets/default_profile.png')));

    return Scaffold(
      appBar: AppBar(title: const Text("Edit Profil")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Center(
              child: GestureDetector(
                onTap: _pickImage,
                child: CircleAvatar(
                  radius: 50,
                  backgroundImage: profileImage as ImageProvider,
                ),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: namaController,
              decoration: const InputDecoration(labelText: 'Nama Lengkap'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: alamatController,
              decoration: const InputDecoration(labelText: 'Alamat'),
              maxLines: 2,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: noTeleponController,
              decoration: const InputDecoration(labelText: 'No. Telepon'),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _saveProfile,
              child: const Text("Simpan"),
            ),
          ],
        ),
      ),
    );
  }
}
