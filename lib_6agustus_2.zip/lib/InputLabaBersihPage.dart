import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class InputLabaBersihPage extends StatefulWidget {
  final DateTime tanggal;

  const InputLabaBersihPage({
    super.key,
    required this.tanggal,
  });

  @override
  State<InputLabaBersihPage> createState() => _InputLabaBersihPageState();
}

class _InputLabaBersihPageState extends State<InputLabaBersihPage> {
  int totalPemasukan = 0;
  int totalPengeluaran = 0;
  int totalHPP = 0;

  String? idCabang; // disimpan setelah ambil dari profiles

  final penyusutanController = TextEditingController();
  final servisKantorController = TextEditingController();

  int get labaKotor => totalPemasukan - totalHPP;
  int get labaSebelumBiayaTetap => labaKotor - totalPengeluaran;
  int get labaBersih => labaSebelumBiayaTetap - biayaTetap;

  int get biayaTetap {
    final sewa = int.tryParse(penyusutanController.text) ?? 0;
    final servis = int.tryParse(servisKantorController.text) ?? 0;
    return sewa + servis;
  }

  DateTime? _startDate;
  DateTime? _endDate;

  @override
  void initState() {
    super.initState();
    _loadCabangAndFetch().then((_) {
      _fetchPemasukan();
      _fetchPengeluaran();
      _fetchHPP();
    });
  }

  /// Ambil id_cabang user login dari tabel profiles
  Future<void> _loadCabangAndFetch() async {
    final supabase = Supabase.instance.client;
    try {
      final userProfile = await supabase
          .from('profiles')
          .select('id_cabang')
          .eq('id', supabase.auth.currentUser!.id)
          .maybeSingle();

      if (userProfile == null || userProfile['id_cabang'] == null) {
        print("❌ ID cabang tidak ditemukan di profiles.");
        return;
      }

      setState(() {
        idCabang = userProfile['id_cabang'];
      });

      print("✅ ID Cabang ditemukan: $idCabang");
    } catch (e) {
      print("Error ambil id_cabang: $e");
    }
  }

  Future<void> _pickStartDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _startDate ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        _startDate = picked;
      });
    }
  }

  Future<void> _pickEndDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _endDate ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        _endDate = picked;
      });
    }
  }

  Future<void> _fetchPemasukan() async {
    if (_startDate == null || _endDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Pilih tanggal awal dan akhir terlebih dahulu")),
      );
      return;
    }

    if (idCabang == null) {
      print("❌ ID cabang belum tersedia.");
      return;
    }

    final supabase = Supabase.instance.client;
    final start = DateFormat('yyyy-MM-dd').format(_startDate!);
    final end = DateFormat('yyyy-MM-dd').format(_endDate!);

    try {
      final response = await supabase
          .from('rekap_omzet_harian')
          .select('total_omzet')
          .eq('id_cabang', idCabang) // gunakan id_cabang dari profiles
          .gte('tanggal', start)
          .lte('tanggal', end);

      int total = 0;
      for (final row in response) {
        total += (row['total_omzet'] ?? 0) as int;
      }

      setState(() {
        totalPemasukan = total;
      });
    } catch (e) {
      print("Error ambil pemasukan: $e");
    }
  }

  Future<void> _fetchPengeluaran() async {
    if (idCabang == null || _startDate == null || _endDate == null) return;

    final start = DateFormat('yyyy-MM-dd').format(_startDate!);
    final end = DateFormat('yyyy-MM-dd').format(_endDate!);

    final response = await Supabase.instance.client
        .from('rekap_pengeluaran_harian')
        .select('total_pengeluaran')
        .eq('id_cabang', idCabang)
        .gte('tanggal', start)  // Menggunakan tanggal awal
        .lte('tanggal', end);   // Menggunakan tanggal akhir

    int totalPengeluaran = 0;
    for (final row in response) {
      totalPengeluaran += (row['total_pengeluaran'] ?? 0) as int;
    }

    setState(() {
      // Menggunakan absolute value untuk memastikan total pengeluaran positif
      this.totalPengeluaran = totalPengeluaran.abs();  // Jika ingin menggunakan nilai absolut
      // Jika pengeluaran harus bernilai negatif, cukup hilangkan `.abs()` dan biarkan seperti semula
    });
  }

  Future<void> _fetchHPP() async {
    if (_startDate == null || _endDate == null || idCabang == null) return;

    final start = DateFormat('yyyy-MM-dd').format(_startDate!);
    final end = DateFormat('yyyy-MM-dd').format(_endDate!);

    final response = await Supabase.instance.client
        .from('rekap_bahan_pokok')
        .select('total')
        .eq('id_cabang', idCabang)
        .gte('tanggal', start)
        .lte('tanggal', end);

    int total = 0;
    for (final row in response) {
      total += (row['total'] ?? 0) as int;
    }

    setState(() {
      totalHPP = total;
    });
  }

  Future<void> _saveLaporan() async {
    if (idCabang == null) {
      print("❌ ID cabang tidak ditemukan.");
      return;
    }

    final supabase = Supabase.instance.client;
    final start = DateFormat('yyyy-MM-dd').format(_startDate!);
    final end = DateFormat('yyyy-MM-dd').format(_endDate!);

    try {
      final response = await supabase
          .from('laba_bersih')
          .insert([
        {
          'id_cabang': idCabang,  // Menggunakan id_cabang dari login atau profil pengguna
          'tanggal': start,  // Tanggal awal
          'pemasukan': totalPemasukan,
          'beban_pokok_penjualan': totalHPP,
          'laba_kotor': labaKotor,
          'beban_usaha': totalPengeluaran,
          'total_laba_bersih': labaBersih,
        }
      ])
          .single();  // Menyimpan satu laporan laba bersih

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Laporan berhasil disimpan")),
      );
    } catch (e) {
      print("Error simpan laporan: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gagal menyimpan laporan")),
      );
    }
  }

  String _format(int value) {
    return NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0).format(value);
  }

  @override
  Widget build(BuildContext context) {
    final tanggalFormatted = DateFormat('dd MMMM yyyy', 'id_ID').format(widget.tanggal);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          'Input Laba Bersih',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFC1CC), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, kToolbarHeight + 24, 24, 24),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: InkWell(
                          onTap: _pickStartDate,
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey),
                              borderRadius: BorderRadius.circular(8),
                              color: Colors.white.withOpacity(0.8),
                            ),
                            child: Text(
                              _startDate == null
                                  ? "Pilih Tanggal Awal"
                                  : DateFormat('dd MMM yyyy', 'id_ID').format(_startDate!),
                              style: const TextStyle(fontSize: 14),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: InkWell(
                          onTap: _pickEndDate,
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey),
                              borderRadius: BorderRadius.circular(8),
                              color: Colors.white.withOpacity(0.8),
                            ),
                            child: Text(
                              _endDate == null
                                  ? "Pilih Tanggal Akhir"
                                  : DateFormat('dd MMM yyyy', 'id_ID').format(_endDate!),
                              style: const TextStyle(fontSize: 14),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        onPressed: () async {
                          await _fetchPemasukan();
                          await _fetchPengeluaran();
                          await _fetchHPP();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green.shade100,
                          foregroundColor: Colors.green.shade900,
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                        ),
                        child: const Text("Tampilkan"),
                      ),
                    ],
                  ),
                ),
                Text("Tanggal: $tanggalFormatted", style: const TextStyle(fontSize: 18)),
                const SizedBox(height: 16),
                _infoCard("Pemasukan", _format(totalPemasukan), Icons.trending_up),
                _infoCard("Beban Pokok Penjualan (HPP)", _format(totalHPP), Icons.shopping_cart),
                _infoCard("Laba Kotor", _format(labaKotor), Icons.bar_chart),
                _infoCard("Beban Usaha", _format(totalPengeluaran), Icons.money_off),
                const SizedBox(height: 16),
                const Divider(),
                const SizedBox(height: 12),
                const Text("Biaya Tetap Lainnya", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                const SizedBox(height: 12),
                _buildInputField("Sewa & Penyusutan", penyusutanController),
                const SizedBox(height: 12),
                _buildInputField("Servis Kantor", servisKantorController),
                const SizedBox(height: 24),
                _infoCard("Laba Bersih", _format(labaBersih), Icons.star, highlight: true),
                const SizedBox(height: 24),
                Center(
                  child: ElevatedButton.icon(
                    onPressed: _saveLaporan,  // Fungsi untuk menyimpan laporan
                    icon: const Icon(Icons.save),
                    label: const Text("Simpan Laporan"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      minimumSize: const Size.fromHeight(50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoCard(String label, String value, IconData icon, {bool highlight = false}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: highlight ? Colors.green.shade50 : Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(children: [
            Icon(icon, color: Colors.black),
            const SizedBox(width: 12),
            Text(label, style: const TextStyle(fontSize: 16)),
          ]),
          Text(value, style: TextStyle(fontWeight: FontWeight.bold, color: highlight ? Colors.green : Colors.black)),
        ],
      ),
    );
  }

  Widget _buildInputField(String label, TextEditingController controller) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        prefixIcon: const Icon(Icons.attach_money),
      ),
      onChanged: (_) => setState(() {}),
    );
  }
}
