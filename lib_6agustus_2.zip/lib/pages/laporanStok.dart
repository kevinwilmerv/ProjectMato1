import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class LaporanStok extends StatefulWidget {
  final String idCabang;
  const LaporanStok({super.key, required this.idCabang});

  @override
  State<LaporanStok> createState() => _LaporanStokState();
}

class _LaporanStokState extends State<LaporanStok> {
  final supabase = Supabase.instance.client;

  String? selectedKategori;
  List<String> kategoriList = [];
  List<Map<String, dynamic>> bahanList = [];

  Map<String, TextEditingController> awalCtrl = {};
  Map<String, TextEditingController> beliCtrl = {};
  Map<String, TextEditingController> ambilCtrl = {};
  Map<String, num> stokAkhir = {};

  DateTime? startDate;
  DateTime? endDate;

  @override
  void initState() {
    super.initState();
    _fetchKategori();
  }

  Future<void> _fetchKategori() async {
    final response = await supabase
        .from('bahan_pokok')
        .select('jenis')
        .eq('id_cabang', widget.idCabang)
        .order('jenis');

    final distinctKategori = response.map((e) => e['jenis'] as String).toSet().toList();
    setState(() {
      kategoriList = distinctKategori;
    });
  }

  Future<void> _fetchBahan(String kategori) async {
    final response = await supabase
        .from('bahan_pokok')
        .select('id, nama_bahan')
        .eq('id_cabang', widget.idCabang)
        .eq('jenis', kategori)
        .order('nama_bahan');

    bahanList = List<Map<String, dynamic>>.from(response);

    awalCtrl.clear();
    beliCtrl.clear();
    ambilCtrl.clear();
    stokAkhir.clear();

    for (var bahan in bahanList) {
      awalCtrl[bahan['id']] = TextEditingController(text: "0");
      beliCtrl[bahan['id']] = TextEditingController(text: "0");
      ambilCtrl[bahan['id']] = TextEditingController(text: "0");
      stokAkhir[bahan['id']] = 0;
    }

    setState(() {});
  }

  void _hitungStok(String idBahan) {
    final awal = num.tryParse(awalCtrl[idBahan]!.text) ?? 0;
    final beli = num.tryParse(beliCtrl[idBahan]!.text) ?? 0;
    final ambil = num.tryParse(ambilCtrl[idBahan]!.text) ?? 0;
    stokAkhir[idBahan] = awal + beli - ambil;
    setState(() {});
  }

  Future<void> _simpanData() async {
    if (startDate == null || endDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Pilih range tanggal terlebih dahulu")),
      );
      return;
    }

    for (var d = startDate!;
    d.isBefore(endDate!.add(const Duration(days: 1)));
    d = d.add(const Duration(days: 1))) {
      for (var bahan in bahanList) {
        final idBahan = bahan['id'];
        await supabase.from('laporan_stok').insert({
          'id_cabang': widget.idCabang,
          'tanggal': DateFormat('yyyy-MM-dd').format(d),
          'bahan_pokok_id': idBahan,
          'kategori': selectedKategori,
          'nama_bahan': bahan['nama_bahan'],
          'awal': num.tryParse(awalCtrl[idBahan]!.text) ?? 0,
          'beli': num.tryParse(beliCtrl[idBahan]!.text) ?? 0,
          'ambil': num.tryParse(ambilCtrl[idBahan]!.text) ?? 0,
          'stok_akhir': stokAkhir[idBahan] ?? 0,
        });
      }
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Data stok berhasil disimpan")),
    );
  }

  Future<void> _pickDateRange(bool isStart) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: isStart ? (startDate ?? DateTime.now()) : (endDate ?? DateTime.now()),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        if (isStart) {
          startDate = picked;
        } else {
          endDate = picked;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text("Laporan Stok", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black)),
        centerTitle: false,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFC5CC), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            const SizedBox(height: 80),
            // Dropdown kategori
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                ),
                hint: const Text("Pilih Kategori"),
                value: selectedKategori,
                items: kategoriList
                    .map((kategori) => DropdownMenuItem(
                  value: kategori,
                  child: Text(kategori),
                ))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    selectedKategori = value;
                  });
                  if (value != null) {
                    _fetchBahan(value);
                  }
                },
              ),
            ),
            // Range tanggal
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => _pickDateRange(true),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Text(startDate != null
                            ? DateFormat('dd/MM/yyyy').format(startDate!)
                            : "Tanggal Awal"),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Text("-", style: TextStyle(fontSize: 20)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => _pickDateRange(false),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Text(endDate != null
                            ? DateFormat('dd/MM/yyyy').format(endDate!)
                            : "Tanggal Akhir"),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            // Table
            Expanded(
              child: SingleChildScrollView(
                child: Table(
                  border: TableBorder.all(color: Colors.transparent),
                  columnWidths: const {
                    0: FlexColumnWidth(2),
                    1: FlexColumnWidth(),
                    2: FlexColumnWidth(),
                    3: FlexColumnWidth(),
                    4: FlexColumnWidth(),
                  },
                  children: [
                    TableRow(
                      decoration: BoxDecoration(color: Colors.white.withOpacity(0.5)),
                      children: const [
                        Padding(padding: EdgeInsets.all(8), child: Text("Nama", style: TextStyle(fontWeight: FontWeight.bold))),
                        Padding(padding: EdgeInsets.all(8), child: Text("Awal", style: TextStyle(fontWeight: FontWeight.bold))),
                        Padding(padding: EdgeInsets.all(8), child: Text("Beli", style: TextStyle(fontWeight: FontWeight.bold))),
                        Padding(padding: EdgeInsets.all(8), child: Text("Ambil", style: TextStyle(fontWeight: FontWeight.bold))),
                        Padding(padding: EdgeInsets.all(8), child: Text("Stok Akhir", style: TextStyle(fontWeight: FontWeight.bold))),
                      ],
                    ),
                    ...bahanList.map((bahan) {
                      final idBahan = bahan['id'];
                      return TableRow(
                        children: [
                          Padding(padding: const EdgeInsets.all(8), child: Text(bahan['nama_bahan'])),
                          Padding(
                            padding: const EdgeInsets.all(4),
                            child: TextField(
                              controller: awalCtrl[idBahan],
                              keyboardType: TextInputType.number,
                              onChanged: (_) => _hitungStok(idBahan),
                              decoration: const InputDecoration(border: InputBorder.none),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(4),
                            child: TextField(
                              controller: beliCtrl[idBahan],
                              keyboardType: TextInputType.number,
                              onChanged: (_) => _hitungStok(idBahan),
                              decoration: const InputDecoration(border: InputBorder.none),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(4),
                            child: TextField(
                              controller: ambilCtrl[idBahan],
                              keyboardType: TextInputType.number,
                              onChanged: (_) => _hitungStok(idBahan),
                              decoration: const InputDecoration(border: InputBorder.none),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8),
                            child: Text("${stokAkhir[idBahan] ?? 0}"),
                          ),
                        ],
                      );
                    }),
                  ],
                ),
              ),
            ),
            // Simpan Semua Button
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton(
                onPressed: _simpanData,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                child: const Text("Simpan Semua", style: TextStyle(color: Colors.white, fontSize: 16)),
              ),
            )
          ],
        ),
      ),
    );
  }
}
