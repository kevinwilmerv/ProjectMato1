import 'dart:io';

typedef PickedFileLocal = File;
