import 'package:supabase_flutter/supabase_flutter.dart';

class LogService {
  final supabase = Supabase.instance.client;

  Future<void> addLog({
    required String aktivitas,
    String? halaman,
    String? detail,
  }) async {
    try {
      // Ambil user yang sedang login
      final user = supabase.auth.currentUser;
      if (user == null) throw Exception("User belum login");

      // Ambil data profil
      final profile = await supabase
          .from('profiles')
          .select('nama, role')
          .eq('id', user.id)
          .maybeSingle();

      if (profile == null) throw Exception("Data profil tidak ditemukan");

      final nama = profile['nama'] ?? 'Unknown';
      final role = profile['role'] ?? 'Unknown';

      // Insert log ke tabel log_aktivitas
      await supabase.from('log_aktivitas').insert({
        'user_id': user.id, // WAJIB
        'nama': nama,       // WAJIB
        'role': role,       // WAJIB
        'aktivitas': aktivitas,
        'halaman': halaman,
        'detail': detail,
        'waktu': DateTime.now().toIso8601String(), // optional, Supabase bisa default
      });

    } catch (e) {
      print("❌ Gagal menambahkan log: $e");
    }
  }
}
