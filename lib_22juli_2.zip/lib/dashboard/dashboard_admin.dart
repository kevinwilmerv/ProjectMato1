import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:iconsax/iconsax.dart';

class DashboardAdmin extends StatefulWidget {
  const DashboardAdmin({super.key});

  @override
  State<DashboardAdmin> createState() => _DashboardAdminState();
}

class _DashboardAdminState extends State<DashboardAdmin> {
  int _selectedIndex = 0;
  final _searchController = TextEditingController();
  List<dynamic> _allCabang = [];
  List<dynamic> _filteredCabang = [];

  @override
  void initState() {
    super.initState();
    fetchCabang();
    _searchController.addListener(_onSearchChanged);
  }

  void _onTabSelected(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Future<void> fetchCabang() async {
    final response = await Supabase.instance.client
        .from('cabang') // nama tabel cabang di Supabase
        .select();

    setState(() {
      _allCabang = response;
      _filteredCabang = response;
    });
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredCabang = _allCabang.where((cabang) {
        final nama = cabang['nama_cabang'].toLowerCase();
        final lokasi = cabang['lokasi'].toLowerCase();
        return nama.contains(query) || lokasi.contains(query);
      }).toList();
    });
  }

  final List<Widget> _pages = [
    const Center(child: Text("Dashboard Page")),
    const Center(child: Text("Laporan Page")),
    const Center(child: Text("Mato Page")),
    // Cabang Page diambil dari Supabase
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Builder(
                  builder: (context) => IconButton(
                    icon: const Icon(Icons.menu, size: 34, color: Colors.black),
                    onPressed: () => Scaffold.of(context).openDrawer(),
                  ),
                ),
                const SizedBox(width: 16),
                Row(
                  children: [
                    Image.asset('assets/logobg.png', height: 85),
                    const SizedBox(width: 10),
                    RichText(
                      text: const TextSpan(
                        children: [
                          TextSpan(text: 'SIMPANG ', style: TextStyle(color: Colors.black, fontSize: 30)),
                          TextSpan(text: 'RAYA', style: TextStyle(color: Colors.red, fontSize: 30, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: const [
                    Text('ADMIN UTAMA', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black)),
                    Text('OWNER', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFFFD1D1), Colors.white],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Admin Cabang', style: TextStyle(color: Colors.black, fontSize: 20)),
                  SizedBox(height: 8),
                  Text('depo.simpraya@example.com', style: TextStyle(color: Colors.black54)),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              onTap: () {
                Navigator.pop(context);
                Future.delayed(const Duration(milliseconds: 300), () {
                  Navigator.of(context).pushReplacementNamed('/login');
                });
              },
            ),
          ],
        ),
      ),
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFD1D1), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            const SizedBox(height: 150),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _navButton('Dashboard', Iconsax.category, 0),
                  const SizedBox(width: 15),
                  _navButton('Laporan', Iconsax.chart_square, 1),
                  const SizedBox(width: 15),
                  _navButton('Mato', Iconsax.chart, 2),
                  const SizedBox(width: 15),
                  _navButton('Cabang', Iconsax.house, 3),
                ],
              ),
            ),
            const SizedBox(height: 30),
            Expanded(child: _selectedIndex == 3 ? _buildCabangPage() : _pages[_selectedIndex]),
          ],
        ),
      ),
    );
  }

  Widget _navButton(String label, IconData icon, int index) {
    final bool isActive = _selectedIndex == index;
    return InkWell(
      onTap: () => _onTabSelected(index),
      borderRadius: BorderRadius.circular(40),
      child: Container(
        width: 180,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: isActive ? const Color(0xFFFFC5CC) : Colors.white,
          borderRadius: BorderRadius.circular(40),
          boxShadow: const [
            BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(2, 4)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.black),
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16, color: Colors.black)),
          ],
        ),
      ),
    );
  }

  Widget _buildCabangPage() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          child: TextField(
            controller: _searchController,
            decoration: InputDecoration(
              hintText: 'Cari cabang...',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            ),
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(
              spacing: 16,
              runSpacing: 16,
              children: _filteredCabang.map((cabang) => _buildCabangCard(cabang)).toList(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCabangCard(dynamic cabang) {
    Color statusColor;
    String status = cabang['status'];
    switch (status.toLowerCase()) {
      case 'bahan naik 10%':
        statusColor = Colors.red[200]!;
        break;
      case 'hpp terkendali':
        statusColor = Colors.green[200]!;
        break;
      default:
        statusColor = Colors.blue[200]!;
    }

    return Container(
      width: 300,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(cabang['kode_cabang'] ?? '', style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 4),
          Text(cabang['nama_cabang'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          Text(cabang['lokasi'] ?? '', style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 12),
          Text(cabang['omzet_harian'] ?? 'Rp. 0', style: const TextStyle(color: Colors.orange, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(color: statusColor, borderRadius: BorderRadius.circular(12)),
            alignment: Alignment.center,
            child: Text(status, style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}
