import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class InputTransaksiPage extends StatefulWidget {
  const InputTransaksiPage({super.key});

  @override
  State<InputTransaksiPage> createState() => _InputTransaksiPageState();
}

class _InputTransaksiPageState extends State<InputTransaksiPage> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, TextEditingController> controllers = {};
  DateTime selectedDate = DateTime.now();

  String? idCabang; // ← Akan diisi dari Supabase
  final supabase = Supabase.instance.client;

  final List<String> omzetFields = ['cash', 'debit', 'kredit', 'gofood', 'ovo', 'gopay'];
  final List<String> pengeluaranFields = ['pajak', 'menu_karyawan', 'iuran_sampah', 'bensin_servis', 'listrik_telepon', 'lain_lain'];

  @override
  void initState() {
    super.initState();
    for (var field in [...omzetFields, ...pengeluaranFields]) {
      controllers[field] = TextEditingController();
    }
    _loadCabangID();
  }

  Future<void> _loadCabangID() async {
    final user = supabase.auth.currentUser;
    if (user != null) {
      final res = await supabase
          .from('profiles')
          .select('id_cabang')
          .eq('id', user.id)
          .maybeSingle();
      setState(() {
        idCabang = res?['id_cabang'];
      });
    }
  }

  @override
  void dispose() {
    for (var c in controllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  int getTotalPemasukan() => omzetFields.map((f) => int.tryParse(controllers[f]?.text ?? '0') ?? 0).fold(0, (a, b) => a + b);
  int getTotalPengeluaran() => pengeluaranFields.map((f) => int.tryParse(controllers[f]?.text ?? '0') ?? 0).fold(0, (a, b) => a + b);
  int getTotalOmzetBersih() => getTotalPemasukan() - getTotalPengeluaran();

  Future<void> _simpanData() async {
    if (!_formKey.currentState!.validate()) return;
    if (idCabang == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cabang belum dimuat.')));
      return;
    }

    final data = {
      'tanggal': selectedDate.toIso8601String(),
      'total_pemasukan': getTotalPemasukan(),
      'total_pengeluaran': getTotalPengeluaran(),
      'total_omset_bersih': getTotalOmzetBersih(),
      'id_cabang': idCabang, // ← ambil otomatis dari Supabase
      ...omzetFields.asMap().map((_, value) => MapEntry(value, int.tryParse(controllers[value]?.text ?? '0') ?? 0)),
      ...pengeluaranFields.asMap().map((_, value) => MapEntry(value, int.tryParse(controllers[value]?.text ?? '0') ?? 0)),
    };

    try {
      await supabase.from('transaksi_harian').insert(data);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Transaksi berhasil disimpan')));
      _formKey.currentState!.reset();
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal menyimpan: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Input Transaksi Harian"),
        actions: [
          IconButton(icon: const Icon(Icons.save), onPressed: _simpanData),
        ],
      ),
      body: idCabang == null
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ElevatedButton(
                onPressed: () async {
                  final date = await showDatePicker(
                    context: context,
                    initialDate: selectedDate,
                    firstDate: DateTime(2020),
                    lastDate: DateTime.now(),
                  );
                  if (date != null) setState(() => selectedDate = date);
                },
                child: Text(
                  'Tanggal Transaksi: ${DateFormat('dd MMM yyyy').format(selectedDate)}',
                  style: const TextStyle(fontSize: 16),
                ),
              ),
              const SizedBox(height: 24),
              const Text("PEMASUKAN (OMZET)", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              ...omzetFields.map((f) => _buildNumberInput(f.toUpperCase(), f, "Masukkan jumlah $f")),
              _buildTotalCard("TOTAL PEMASUKAN", getTotalPemasukan()),
              const SizedBox(height: 24),
              const Text("PENGELUARAN", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              ...pengeluaranFields.map((f) => _buildNumberInput(f.replaceAll("_", " ").toUpperCase(), f, "Masukkan $f")),
              _buildTotalCard("TOTAL PENGELUARAN", getTotalPengeluaran()),
              const SizedBox(height: 24),
              Card(
                color: Colors.green[50],
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      const Text("TOTAL OMSET BERSIH:", style: TextStyle(fontWeight: FontWeight.bold)),
                      Text(
                        "Rp ${NumberFormat.decimalPattern().format(getTotalOmzetBersih())}",
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNumberInput(String label, String key, String hint) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: TextFormField(
        controller: controllers[key],
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: const OutlineInputBorder(),
        ),
        validator: (value) => (value == null || value.isEmpty) ? 'Harap masukkan jumlah' : null,
        onChanged: (_) => setState(() {}),
      ),
    );
  }

  Widget _buildTotalCard(String label, int total) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
            Text("Rp ${NumberFormat.decimalPattern().format(total)}",
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}
