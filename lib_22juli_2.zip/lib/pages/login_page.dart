import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:laporan_keuangan1/dashboard/dashboard_cabang.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final supabase = Supabase.instance.client;

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController adminKeyController = TextEditingController();

  String? selectedRole;
  String? selectedCabang;

  List<Map<String, dynamic>> cabangList = [];
  bool isLoading = false;
  bool isCabangLoading = false;

  final String requiredAdminKey = 'SUP3RADM1N';

  @override
  void initState() {
    super.initState();
    // Tidak perlu cek selectedRole, langsung fetch semua cabang di awal
    fetchCabang();
  }


  void showMessage(String message, {bool success = false}) {
    final color = success ? Colors.green : Colors.red;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: color),
    );
  }

  Future<void> fetchCabang() async {
    setState(() => isCabangLoading = true);
    try {
      final response = await supabase.from('cabang').select();
      print("Response cabang: $response");
      print (response);

      setState(() {
        cabangList = List<Map<String, dynamic>>.from(response);
      });
    } catch (e) {
      showMessage("Gagal memuat cabang: $e");
    } finally {
      setState(() => isCabangLoading = false);
    }
  }


  Future<void> login() async {
    final email = emailController.text.trim();
    final password = passwordController.text.trim();

    if (email.isEmpty || password.isEmpty || selectedRole == null) {
      showMessage("Email, password, dan role wajib diisi.");
      return;
    }

    if (selectedRole == 'admin_pusat' && adminKeyController.text != requiredAdminKey) {
      showMessage("Kode rahasia salah untuk Admin Pusat!");
      return;
    }

    if ((selectedRole == 'admin_cabang' || selectedRole == 'staff') && selectedCabang == null) {
      showMessage("Cabang wajib dipilih.");
      return;
    }

    setState(() => isLoading = true);

    try {
      final response = await supabase.auth.signInWithPassword(
        email: email,
        password: password,
      );

      final user = response.user;
      if (user == null) {
        showMessage("Login gagal. Pengguna tidak ditemukan.");
        return;
      }

      final userData = await supabase
          .from('profiles')
          .select('nama, role, id_cabang')
          .eq('id', user.id)
          .maybeSingle();

      if (userData == null) {
        showMessage("Data pengguna tidak ditemukan.");
        return;
      }

      final role = userData['role'];
      final nama = userData['nama'];
      final idCabang = userData['id_cabang'];

      showMessage("Selamat datang, $nama ($role)", success: true);

      if (role == 'admin_pusat') {
        Navigator.pushReplacementNamed(context, '/dashboard-admin');
      } else if (role == 'admin_cabang') {
        if (idCabang == null) {
          showMessage("ID Cabang tidak ditemukan untuk admin_cabang.");
          return;
        }

        final cabangData = await supabase
            .from('cabang')
            .select('nama_cabang')
            .eq('id_cabang', idCabang)
            .maybeSingle();

        final namaCabang = cabangData?['nama_cabang'] ?? 'Cabang';

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => DashboardCabang(
              idCabang: idCabang,
              namaCabang: namaCabang,
            ),
          ),
        );
      } else if (role == 'staff') {
        Navigator.pushReplacementNamed(context, '/dashboard_staff');
      } else {
        showMessage("Role tidak dikenali.");
      }
    } catch (e) {
      showMessage("Terjadi kesalahan saat login: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFD1D1), Colors.white],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: Card(
              color: Colors.white.withOpacity(0.95),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 10,
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      "Masuk Akun",
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 24),
                    TextField(
                      controller: emailController,
                      decoration: const InputDecoration(labelText: 'Email'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: passwordController,
                      obscureText: true,
                      decoration: const InputDecoration(labelText: 'Password'),
                    ),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      value: selectedRole,
                      decoration: const InputDecoration(labelText: 'Role'),
                      items: const [
                        DropdownMenuItem(
                          value: 'admin_pusat',
                          child: Text('Admin Pusat (khusus)'),
                        ),
                        DropdownMenuItem(
                          value: 'admin_cabang',
                          child: Text('Admin Cabang'),
                        ),
                        DropdownMenuItem(
                          value: 'staff',
                          child: Text('Staff'),
                        ),
                      ],
                      onChanged: (value) {
                        setState(() {
                          selectedRole = value;
                          selectedCabang = null;
                          adminKeyController.clear();

                          if (value == 'admin_cabang' || value == 'staff') {
                            fetchCabang();
                          }
                        });
                      },
                    ),
                    const SizedBox(height: 16),

                    if (selectedRole == 'admin_pusat') ...[
                      TextField(
                        controller: adminKeyController,
                        obscureText: true,
                        decoration: const InputDecoration(labelText: 'Kode Rahasia Admin Pusat'),
                      ),
                      const SizedBox(height: 16),
                    ],

                    if ((selectedRole == 'admin_cabang' || selectedRole == 'staff')) ...[
                      isCabangLoading
                          ? const Center(child: CircularProgressIndicator())
                          : cabangList.isEmpty
                          ? const Text('Tidak ada data cabang ditemukan')
                          : DropdownButtonFormField<String>(
                        value: selectedCabang,
                        onChanged: (val) {
                          setState(() => selectedCabang = val);
                        },
                        decoration: const InputDecoration(labelText: 'Pilih Cabang'),
                        items: cabangList
                            .map((cabang) => DropdownMenuItem<String>(
                          value: cabang['id_cabang'],
                          child: Text('${cabang['nama_cabang']} (${cabang['id_cabang']})'),
                        ))
                            .toList(),
                      ),
                      const SizedBox(height: 16),
                    ],

                    const SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: isLoading ? null : login,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.indigo,
                        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: isLoading
                          ? const CircularProgressIndicator(color: Colors.white)
                          : const Text(
                        'Login',
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextButton(
                      onPressed: () => Navigator.pushReplacementNamed(context, '/register'),
                      child: const Text('Belum punya akun? Daftar di sini'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
