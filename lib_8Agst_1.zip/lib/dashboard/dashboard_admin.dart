import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:laporan_keuangan1/log_page.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:laporan_keuangan1/InputTransaksiPage.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:pdf/pdf.dart';
import 'package:flutter/rendering.dart';
import 'package:laporan_keuangan1/pages/laporanIncomeMato.dart';
import 'package:laporan_keuangan1/pages/laporanInvestor.dart';
import 'package:laporan_keuangan1/pages/laporanStok.dart';
import 'package:laporan_keuangan1/log_service.dart';
import 'package:iconsax/iconsax.dart';

class DashboardAdmin extends StatefulWidget {
  const DashboardAdmin({super.key});

  @override
  State<DashboardAdmin> createState() => _DashboardAdminState();
}

class _DashboardAdminState extends State<DashboardAdmin> {
  int _selectedIndex = 0;
  final _searchController = TextEditingController();
  List<dynamic> _allCabang = [];
  List<dynamic> _filteredCabang = [];
  DateTime selectedDate = DateTime.now();
  Map<String, dynamic>? omzetData;
  List<dynamic> daftarPegawai = [];
  String? userEmail;

  final GlobalKey _chartKeySales = GlobalKey();
  final GlobalKey _chartKeyMato = GlobalKey();
  final GlobalKey _chartKeyHPP = GlobalKey();
  final logService = LogService();


  DateTime? _startDate;
  DateTime? _endDate;

  List<Map<String, dynamic>> _omzetData = [];

  Future<void> _loadOmzetData() async {
    final data = await _fetchOmzetFromSupabase();
    setState(() {
      _omzetData = data;
    });
  }


  @override
  void initState() {
    super.initState();
    fetchCabang();
    _searchController.addListener(_onSearchChanged);
    final user = Supabase.instance.client.auth.currentUser;
    setState(() {
      userEmail = user?.email;
    });
    _loadOmzetData();
  }

  void _onTabSelected(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  List<Map<String, dynamic>> _filterOmzetData(
      List<Map<String, dynamic>> data,
      ) {
    // Kalau tidak ada filter tanggal, kembalikan semua data
    if (_startDate == null && _endDate == null) {
      return data;
    }

    return data.where((item) {
      try {
        final tanggal = DateTime.parse(item['tanggal']);

        // Jika ada _startDate, pastikan tanggal >= _startDate
        if (_startDate != null && tanggal.isBefore(_startDate!)) {
          return false;
        }

        // Jika ada _endDate, pastikan tanggal <= _endDate
        if (_endDate != null && tanggal.isAfter(_endDate!)) {
          return false;
        }

        return true;
      } catch (e) {
        // Jika parsing tanggal gagal, skip data
        return false;
      }
    }).toList();
  }

  Future<List<Map<String, dynamic>>> fetchPegawaiDetail(String idCabang) async {
    final supabase = Supabase.instance.client;

    final response = await supabase
        .from('profiles')
        .select()
        .eq('id_cabang', idCabang);

    return List<Map<String, dynamic>>.from(response);
  }

  Future<void> fetchCabang() async {
    final response = await Supabase.instance.client
        .from('cabang')
        .select();

    setState(() {
      _allCabang = response;
      _filteredCabang = response;
    });
  }

  Future<List<Map<String, dynamic>>> _fetchHPPFromSupabase() async {
    try {
      final supabase = Supabase.instance.client;

      // Query untuk mengambil data HPP per cabang per hari
      var query = supabase
          .from('bahan_pokok')
          .select('tanggal, id_cabang, total') // Pilih kolom yang dibutuhkan
          .order('tanggal', ascending: true) as PostgrestFilterBuilder; // Pastikan casting ke PostgrestFilterBuilder

      // Filter tanggal awal
      if (_startDate != null) {
        query = query.gte('tanggal', DateFormat('yyyy-MM-dd').format(_startDate!));
      }

      // Filter tanggal akhir
      if (_endDate != null) {
        query = query.lte('tanggal', DateFormat('yyyy-MM-dd').format(_endDate!));
      }

      final response = await query;

      // Agregasi data untuk mendapatkan total HPP per cabang per hari
      final aggregatedData = <String, double>{};

      for (var item in response) {
        final cabangId = item['id_cabang'];
        final totalHPP = item['total'] ?? 0.0; // Mengganti null dengan 0.0

        if (aggregatedData.containsKey(cabangId)) {
          aggregatedData[cabangId] = aggregatedData[cabangId]! + totalHPP;
        } else {
          aggregatedData[cabangId] = totalHPP;
        }
      }

      // Ubah data menjadi format yang diinginkan
      final result = aggregatedData.entries.map((e) {
        return {
          'id_cabang': e.key,
          'total': e.value,
        };
      }).toList();

      return result;
    } catch (e) {
      debugPrint("❌ Error fetch HPP: $e");
      return [];
    }
  }

  Future<int> fetchTotalOmzetByTanggal(String idCabang) async {
    final supabase = Supabase.instance.client;

    // Pastikan order & filter builder benar
    var query = supabase
        .from('rekap_omzet_harian')
        .select('total_omzet')
        .eq('id_cabang', idCabang)
        .order('tanggal', ascending: true) as PostgrestFilterBuilder;

    // Filter tanggal awal
    if (_startDate != null) {
      query = query.gte('tanggal', DateFormat('yyyy-MM-dd').format(_startDate!));
    }

    // Filter tanggal akhir
    if (_endDate != null) {
      query = query.lte('tanggal', DateFormat('yyyy-MM-dd').format(_endDate!));
    }

    final response = await query;

    // Hitung total omzet
    final List data = response is List ? response : [];
    return data.fold<int>(0, (sum, item) => sum + ((item['total_omzet'] ?? 0) as num).toInt());
  }

  Future<void> fetchOmzetDanPegawai(String idCabang, DateTime tanggal) async {
    final supabase = Supabase.instance.client;
    final formattedDate = DateFormat('yyyy-MM-dd').format(tanggal);

    try {
      final omzet = await supabase
          .from('omzet')
          .select('total_hpp')
          .eq('id_cabang', idCabang)
          .eq('tanggal', formattedDate)
          .maybeSingle();

      final pegawai = await supabase
          .from('profiles')
          .select('nama, jabatan')
          .eq('id_cabang', idCabang);

      setState(() {
        omzetData = omzet;
        daftarPegawai = pegawai;
      });
    } catch (e) {
      print('Gagal memuat data: $e');
    }
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredCabang = _allCabang.where((cabang) {
        final nama = cabang['nama_cabang'].toLowerCase();
        final lokasi = cabang['lokasi'].toLowerCase();
        return nama.contains(query) || lokasi.contains(query);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Builder(
                  builder: (context) => IconButton(
                    icon: const Icon(Icons.menu, size: 34, color: Colors.black),
                    onPressed: () => Scaffold.of(context).openDrawer(),
                  ),
                ),
                const SizedBox(width: 16),
                Row(
                  children: [
                    Image.asset('assets/logobg.png', height: 85),
                    const SizedBox(width: 10),
                    RichText(
                      text: const TextSpan(
                        children: [
                          TextSpan(text: 'SIMPANG ', style: TextStyle(color: Colors.black, fontSize: 30)),
                          TextSpan(text: 'RAYA', style: TextStyle(color: Colors.red, fontSize: 30, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: const [
                    Text('ADMIN PUSAT', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black)),
                    Text('OWNER', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFFFD1D1), Colors.white],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Admin Pusat', style: TextStyle(color: Colors.black, fontSize: 20)),
                  const SizedBox(height: 8),
                  Text(userEmail ?? '-', style: const TextStyle(color: Colors.black54)),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.history),
              title: const Text('Log Aktivitas'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const LogPage()),
                );
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              onTap: () {
                Navigator.pop(context);
                Future.delayed(const Duration(milliseconds: 300), () {
                  Navigator.of(context).pushReplacementNamed('/login');
                });
              },
            ),
          ],
        ),
      ),
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFD1D1), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            const SizedBox(height: 150),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _navButton('Dashboard', Iconsax.category, 0),
                  const SizedBox(width: 15),
                  _navButton('Laporan', Iconsax.chart_square, 1),
                  const SizedBox(width: 15),
                  _navButton('Mato', Iconsax.chart, 2),
                  const SizedBox(width: 15),
                  _navButton('Cabang', Iconsax.house, 3),
                ],
              ),
            ),
            const SizedBox(height: 30),
            Expanded(
              child: _selectedIndex == 3
                  ? _buildCabangPage()
                  : _buildContent(), // pakai switch case
            ),
          ],
        ),
      ),

    );
  }

  Widget _buildContent() {
    switch (_selectedIndex) {
      case 0:
        return buildDashboardAdminMainTab(); // Dashboard utama
      case 2: // tab Mato
        return SingleChildScrollView(
          child: _buildRekapMato(),
        );
      case 3:
        return _buildCabangPage(); // ini untuk card cabang + search
      default:
        return const SizedBox();
    }
  }

  Future<List<Map<String, dynamic>>> _fetchSales100Hari() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) throw Exception("User belum login");

    final profile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = profile?['id_cabang'];
    if (idCabang == null) throw Exception("ID cabang tidak ditemukan");

    final queryBuilder = supabase
        .from('sales_100_hari')
        .select()
        .eq('id_cabang', idCabang);

    if (_startDate != null) {
      queryBuilder.filter('tanggal', 'gte', _startDate!.toIso8601String());
    }
    if (_endDate != null) {
      queryBuilder.filter('tanggal', 'lte', _endDate!.toIso8601String());
    }

    final response = await queryBuilder.order('tanggal');

    return List<Map<String, dynamic>>.from(response);
  }

  Widget _buildSalesChart(List<Map<String, dynamic>> data) {
    final List<BarChartGroupData> barGroups = [];
    final List<String> tanggalList = [];

    for (int i = 0; i < data.length; i++) {
      final item = data[i];
      final double y = (item['total_omset'] ?? 0).toDouble();
      final String tanggal = item['tanggal'] ?? '';
      tanggalList.add(tanggal);

      barGroups.add(
        BarChartGroupData(
          x: i,
          barRods: [
            BarChartRodData(toY: y, color: Colors.green),
          ],
        ),
      );
    }

    return AspectRatio(
      aspectRatio: 1.6,
      child: BarChart(
        BarChartData(
          barGroups: barGroups,
          titlesData: FlTitlesData(
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (double value, TitleMeta meta) {
                  final int index = value.toInt();

                  // Pastikan index valid
                  if (index < 0 || index >= tanggalList.length) {
                    return const SizedBox.shrink();
                  }

                  // Format tanggal
                  final formatted = DateFormat('d MMM').format(DateTime.parse(tanggalList[index]));

                  // Hanya tampilkan setiap 10 hari agar tidak penuh
                  if (index % 10 != 0) return const SizedBox.shrink();

                  // Kembalikan teks label
                  return Text(
                    formatted,
                    style: const TextStyle(fontSize: 14),
                  );
                },

                reservedSize: 36,
                interval: 1,
              ),
            ),
            topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 60,
                interval: null, // biar tidak auto generate berdasarkan interval
                getTitlesWidget: (value, meta) {
                  // Cek apakah value ini ada di list omzet
                  final yValues = data.map((item) => item['omzet'].toDouble()).toSet();
                  if (!yValues.contains(value)) return const SizedBox.shrink();

                  if (value >= 1000000) {
                    return Text("Rp ${(value / 1000000).toStringAsFixed(2)} jt",
                        style: const TextStyle(fontSize: 11));
                  } else if (value >= 1000) {
                    return Text("Rp ${(value / 1000).toStringAsFixed(0)} rb",
                        style: const TextStyle(fontSize: 11));
                  }
                  return Text("Rp ${value.toStringAsFixed(0)}",
                      style: const TextStyle(fontSize: 11));
                },
              ),
            ),
          ),
          borderData: FlBorderData(show: false),
          gridData: FlGridData(show: true),
        ),
      ),
    );
  }

  Widget _buildOmzetLineChart(
      List<Map<String, dynamic>> data, {
        String filterType = 'all',
      }) {
    if (data.isEmpty) {
      return const Center(child: Text("Tidak ada data"));
    }

    // Ambil dan akumulasi omzet dari semua tanggal
    final omzetPerTanggal = <String, double>{};

    for (var item in data) {
      final tanggal = item['tanggal'];
      final omzet = (item['total_omzet'] as num).toDouble();
      omzetPerTanggal[tanggal] = (omzetPerTanggal[tanggal] ?? 0) + omzet;
    }

    final sortedKeys = omzetPerTanggal.keys.toList()..sort();
    final omzetValues = sortedKeys.map((k) => omzetPerTanggal[k]!).toList();

    final minValue = omzetValues.reduce((a, b) => a < b ? a : b);
    final maxValue = omzetValues.reduce((a, b) => a > b ? a : b);

    // Naikkan jarak bawah supaya garis tidak terlalu mepet
    final chartMinY = (minValue * 0.2).clamp(0, double.infinity); // dari 0.8 → 0.7
    final chartMaxY = maxValue * 1.2;

    final spots = List.generate(sortedKeys.length, (i) {
      return FlSpot(i.toDouble(), omzetPerTanggal[sortedKeys[i]]!);
    });


    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.6),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.black.withOpacity(0.1), width: 1),
      ),
      child: SizedBox(
        height: 300,
        child: LineChart(
          LineChartData(
            minX: -0.3,
            maxX: sortedKeys.length - 0.7,
            minY: chartMinY.toDouble(),
            maxY: chartMaxY.toDouble(),
            gridData: FlGridData(show: false),
            titlesData: FlTitlesData(
              leftTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 60,
                  getTitlesWidget: (value, meta) {
                    // Tampilkan label hanya untuk nilai yang ada di data
                    final yValues = omzetPerTanggal.values.toSet();
                    if (!yValues.contains(value)) return const SizedBox.shrink();

                    if (value >= 1000000) {
                      return Text("Rp ${(value / 1000000).toStringAsFixed(2)} jt",
                          style: const TextStyle(fontSize: 11));
                    } else if (value >= 1000) {
                      return Text("Rp ${(value / 1000).toStringAsFixed(0)} rb",
                          style: const TextStyle(fontSize: 11));
                    }
                    return Text("Rp ${value.toStringAsFixed(0)}",
                        style: const TextStyle(fontSize: 11));
                  },
                ),
              ),
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  interval: 1,
                  getTitlesWidget: (value, meta) {
                    int index = value.toInt();
                    if (index < 0 || index >= sortedKeys.length) {
                      return const SizedBox();
                    }

                    // Cek posisi pixel untuk menentukan apakah label terlalu di luar chart
                    final distanceFromLeft = value - meta.min;
                    final distanceFromRight = meta.max - value;

                    if (distanceFromLeft < 0.1 || distanceFromRight < 0.1) {
                      // Label terlalu di ujung luar → hilangkan
                      return const SizedBox();
                    }

                    return Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(
                        DateFormat('dd MMM').format(DateTime.parse(sortedKeys[index])),
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    );
                  },
                ),
              ),
              topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
              rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            ),
            borderData: FlBorderData(
              show: true,
              border: Border.all(color: Colors.black),
            ),
            lineBarsData: [
              // Garis utama (omzet)
              LineChartBarData(
                spots: spots,
                isCurved: false,
                color: Colors.blueGrey,
                barWidth: 3,
                dotData: FlDotData(show: false),
              ),
              // Garis bantu vertikal pendek (hanya dari chartMinY ke titik data)
              ...spots.map((spot) {
                return LineChartBarData(
                  spots: [
                    FlSpot(spot.x, chartMinY.toDouble()),
                    FlSpot(spot.x, spot.y),
                  ],
                  isCurved: false,
                  color: Colors.black.withOpacity(0.4),
                  barWidth: 2,
                  dashArray: [4, 4],
                  dotData: FlDotData(show: false),
                );
              }).toList(),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _exportChartToPdf(GlobalKey chartKey) async {
    final pdf = pw.Document();
    final image = await WidgetWraper.wrapWidgetToImage(chartKey);

    if (image != null) {
      pdf.addPage(
        pw.Page(
          build: (pw.Context context) => pw.Center(
            child: pw.Image(pw.MemoryImage(image)),
          ),
        ),
      );
      await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => pdf.save(),
      );
    }
  }

  Future<List<Map<String, dynamic>>> _fetchOmzetFromSupabase() async {
    try {
      final supabase = Supabase.instance.client;

      // Query dasar
      var query = Supabase.instance.client
          .from('rekap_omzet_harian')
          .select('tanggal, total_omzet') // atau '*'
          .order('tanggal', ascending: true) as PostgrestFilterBuilder;

      if (_startDate != null) {
        query = query.gte('tanggal', DateFormat('yyyy-MM-dd').format(_startDate!));
      }

      if (_endDate != null) {
        query = query.lte('tanggal', DateFormat('yyyy-MM-dd').format(_endDate!));
      }

      final response = await query;

      // Konversi hasil ke List<Map<String, dynamic>>
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint("❌ Error fetch omzet: $e");
      return [];
    }
  }

  List<Map<String, dynamic>> _applyDateFilter(List<Map<String, dynamic>> data) {
    return data.where((item) {
      try {
        final tanggal = DateTime.parse(item['tanggal']);
        if (_startDate != null && tanggal.isBefore(_startDate!)) return false;
        if (_endDate != null && tanggal.isAfter(_endDate!)) return false;
        return true;
      } catch (e) {
        return false; // Skip jika parsing gagal
      }
    }).toList();
  }

  Widget buildDashboardAdminMainTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 32),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Filter Tanggal',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: _startDate ?? DateTime.now(),
                        firstDate: DateTime(2020),
                        lastDate: DateTime.now(),
                      );
                      if (picked != null) {
                        setState(() => _startDate = picked);
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        _startDate != null
                            ? 'Dari: ${DateFormat('dd MMM yyyy').format(_startDate!)}'
                            : 'Pilih Tanggal Awal',
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: _endDate ?? DateTime.now(),
                        firstDate: DateTime(2020),
                        lastDate: DateTime.now(),
                      );
                      if (picked != null) {
                        setState(() => _endDate = picked);
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        _endDate != null
                            ? 'Sampai: ${DateFormat('dd MMM yyyy').format(_endDate!)}'
                            : 'Pilih Tanggal Akhir',
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                ElevatedButton(
                  onPressed: () => setState(() {}),
                  child: const Text('Tampilkan'),
                ),
              ],
            ),
            const SizedBox(height: 24),

            const Text(
              'Grafik Sales',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),

            FutureBuilder<List<Map<String, dynamic>>>(
              future: _fetchSales100Hari(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Text('Gagal memuat data sales: ${snapshot.error}');
                }

                // === FILTER TANGGAL GLOBAL ===
                final filteredData = _applyDateFilter(snapshot.data ?? []);

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RepaintBoundary(
                      key: _chartKeySales,
                      child: _buildSalesChart(filteredData), // pakai filteredData
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: () => _exportChartToPdf(_chartKeySales),
                      icon: const Icon(Icons.picture_as_pdf),
                      label: const Text('Export Sales ke PDF'),
                    ),
                  ],
                );
              },
            ),

            const SizedBox(height: 32),
            const Text(
              'Omzet Cabang',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),


            FutureBuilder<List<Map<String, dynamic>>>(
              future: _fetchOmzetFromSupabase(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Text('Gagal memuat omzet: ${snapshot.error}');
                }

                // Ambil data dari snapshot
                final allData = snapshot.data ?? [];

                // Filter data sesuai tanggal yang dipilih pengguna
                final filteredData = _applyDateFilter(snapshot.data ?? []);

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RepaintBoundary(
                      key: _chartKeyMato,
                      child: _buildOmzetLineChart(filteredData),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: () => _exportChartToPdf(_chartKeyMato),
                      icon: const Icon(Icons.picture_as_pdf),
                      label: const Text('Export Omzet ke PDF'),
                    ),
                  ],
                );
              },
            ),

            const SizedBox(height: 32),
            const Text(
              'Grafik HPP',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),

            FutureBuilder<List<Map<String, dynamic>>>(
              future: _fetchHPPFromSupabase(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Text('Gagal memuat HPP: ${snapshot.error}');
                }

                // === FILTER TANGGAL GLOBAL ===
                final allData = snapshot.data ?? [];
                final filteredData = _applyDateFilter(allData); // fungsi helper filter tanggal

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RepaintBoundary(
                      key: _chartKeyHPP,
                      child: _buildOmzetLineChart(filteredData), // Gunakan fungsi chart omzet
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: () => _exportChartToPdf(_chartKeyHPP),
                      icon: const Icon(Icons.picture_as_pdf),
                      label: const Text('Export HPP ke PDF'),
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _navButton(String label, IconData icon, int index) {
    final bool isActive = _selectedIndex == index;
    return InkWell(
      onTap: () => _onTabSelected(index),
      borderRadius: BorderRadius.circular(40),
      child: Container(
        width: 180,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: isActive ? const Color(0xFFFFC5CC) : Colors.white,
          borderRadius: BorderRadius.circular(40),
          boxShadow: const [
            BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(2, 4)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.black),
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16, color: Colors.black)),
          ],
        ),
      ),
    );
  }

  Widget _buildCabangPage() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          child: Center(
            child: SizedBox(
              width: 1240,
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Cari cabang...',
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Scrollbar(
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: Column(
                  children: [
                    Wrap(
                      spacing: 16,
                      runSpacing: 16,
                      children: _filteredCabang
                          .map((cabang) => _buildCabangCard(cabang))
                          .toList(),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _showCabangDetailPopup(BuildContext context, dynamic cabang) async {
    DateTime selectedDate = DateTime.now();
    final supabase = Supabase.instance.client;
    final profiles = await supabase.from('profiles').select().eq('id_cabang', cabang['id_cabang']);
    final jumlahPegawai = profiles.length;
    final totalOmzet = await fetchTotalOmzetByTanggal(cabang['id_cabang']);
    final formatter = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: StatefulBuilder(
            builder: (context, setState) {
              return SizedBox(
                width: MediaQuery.of(context).size.width * 0.9,
                height: MediaQuery.of(context).size.height * 0.85,
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Detail Cabang - ${cabang['nama_cabang']}',
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text('ID Cabang: ${cabang['id_cabang']}'),
                      Text('Lokasi: ${cabang['lokasi']}'),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Omzet: ${formatter.format(totalOmzet)}'),
                          TextButton.icon(
                            icon: const Icon(Icons.date_range),
                            label: Text(DateFormat('dd MMM yyyy').format(selectedDate)),
                            onPressed: () async {
                              final pickedDate = await showDatePicker(
                                context: context,
                                initialDate: selectedDate,
                                firstDate: DateTime(2023),
                                lastDate: DateTime.now(),
                              );
                              if (pickedDate != null) {
                                final newOmzet = await fetchTotalOmzetByTanggal(cabang['id_cabang']);
                                setState(() {
                                  selectedDate = pickedDate;
                                  int totalOmzet = 0; // atau late int totalOmzet;
                                });
                              }
                            },
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text('Jumlah Pegawai: $jumlahPegawai'),
                      const SizedBox(height: 16),
                      const Text('Daftar Pegawai Mingguan',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      const Divider(height: 1),
                      const SizedBox(height: 12),

                      /// ✅ Scrollable Table Area
                      Expanded(
                        child: FutureBuilder<List<Map<String, dynamic>>>(
                          future: fetchPegawaiDetail(cabang['id_cabang']),
                          builder: (context, snapshot) {
                            if (snapshot.connectionState == ConnectionState.waiting) {
                              return const Center(child: CircularProgressIndicator());
                            } else if (snapshot.hasError) {
                              return Center(child: Text('Gagal memuat data: ${snapshot.error}'));
                            }

                            final data = snapshot.data ?? [];
                            if (data.isEmpty) {
                              return const Center(child: Text('Belum ada data pegawai.'));
                            }

                            return InteractiveViewer(
                              constrained: false,
                              scaleEnabled: false,
                              panEnabled: true,
                              child: DataTable(
                                headingRowColor: MaterialStateProperty.all(Colors.grey[200]),
                                columns: const [
                                  DataColumn(label: Text('No')),
                                  DataColumn(label: Text('Nama')),
                                  DataColumn(label: Text('Jabatan')),
                                  DataColumn(label: Text('Mata')),
                                  DataColumn(label: Text('Nilai/Mata')),
                                  DataColumn(label: Text('Pendapatan')),
                                  DataColumn(label: Text('Pinjaman')),
                                  DataColumn(label: Text('Bon Makan')),
                                  DataColumn(label: Text('Bon Gudang')),
                                  DataColumn(label: Text('Absen')),
                                  DataColumn(label: Text('Pot Absen')),
                                  DataColumn(label: Text('Total')),
                                  DataColumn(label: Text('Hasil')),
                                ],
                                rows: data.asMap().entries.map((entry) {
                                  final index = entry.key + 1;
                                  final pegawai = entry.value;
                                  return DataRow(cells: [
                                    DataCell(Text('$index')),
                                    DataCell(Text(pegawai['nama'] ?? '-')),
                                    DataCell(Text(pegawai['jabatan'] ?? '-')),
                                    DataCell(Text('${pegawai['skor_mato'] ?? '-'}')),
                                    DataCell(Text('${pegawai['nilai_per_mata'] ?? '-'}')),
                                    DataCell(Text('${pegawai['pendapatan'] ?? '-'}')),
                                    DataCell(Text('${pegawai['pinjaman'] ?? '-'}')),
                                    DataCell(Text('${pegawai['bon_makan'] ?? '-'}')),
                                    DataCell(Text('${pegawai['bon_gudang'] ?? '-'}')),
                                    DataCell(Text('${pegawai['absen'] ?? '-'}')),
                                    DataCell(Text('${pegawai['pot_absen'] ?? '-'}')),
                                    DataCell(Text('${pegawai['total_mingguan'] ?? '-'}')),
                                    DataCell(Text('${pegawai['hasil'] ?? '-'}')),
                                  ]);
                                }).toList(),
                              ),
                            );
                          },
                        ),
                      ),

                      const SizedBox(height: 12),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          child: const Text('Tutup'),
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Future<num> fetchTotalOmzetHarian(String idCabang) async {
    final supabase = Supabase.instance.client;
    final today = DateTime.now();
    final formattedDate = DateFormat('yyyy-MM-dd').format(today);

    var query = Supabase.instance.client
        .from('omzet')
        .select()
        .eq('id_cabang', idCabang);

    if (_startDate != null) {
      query = query.gte('tanggal', DateFormat('yyyy-MM-dd').format(_startDate!));
    }
    if (_endDate != null) {
      query = query.lte('tanggal', DateFormat('yyyy-MM-dd').format(_endDate!));
    }

    final response = await query;

    final List data = response;
    final total = data.fold<num>(0, (sum, item) => sum + (item['total_hpp'] ?? 0));
    return total;
  }

  Widget _buildCabangCard(dynamic cabang) {
    return Container(
      width: 300,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(cabang['id_cabang'] ?? '', style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 4),
          Text(cabang['nama_cabang'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          Text(cabang['lokasi'] ?? '', style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 12),
          Text(cabang['total_omzet'] ?? 'Rp. 0', style: const TextStyle(color: Colors.orange, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => _showCabangDetailPopup(context, cabang),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green[100],
                foregroundColor: Colors.green[800],
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: 0,
              ),
              child: const Text('Detail', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }
}
class WidgetWraper {
  static Future<Uint8List?> wrapWidgetToImage(GlobalKey key) async {
    try {
      final boundary = key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      final image = await boundary?.toImage(pixelRatio: 2.0);
      final byteData = await image?.toByteData(format: ui.ImageByteFormat.png);
      return byteData?.buffer.asUint8List();
    } catch (_) {
      return null;
    }
  }
}

Widget _buildRekapMato() {
  return const RekapMatoWidget();
}

class RekapMatoWidget extends StatefulWidget {
  const RekapMatoWidget({super.key});

  @override
  State<RekapMatoWidget> createState() => _RekapMatoWidgetState();
}

class _RekapMatoWidgetState extends State<RekapMatoWidget> {
  final supabase = Supabase.instance.client;

  List<Map<String, dynamic>> data = [];
  String sortField = 'income_per_mato';
  String sortOrder = 'desc';
  bool isLoading = true;

  final GlobalKey<AnimatedListState> _listKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      final response = await supabase
          .from('cabang')
          .select('id_cabang, nama_cabang, skor_mato, total_income');

      if (response.isEmpty) {
        setState(() {
          data = []; // biarkan kosong, nanti placeholder muncul
          isLoading = false;
        });
        return;
      }

      List<Map<String, dynamic>> listData =
      List<Map<String, dynamic>>.from(response);

      for (var item in listData) {
        final skor = (item['skor_mato'] is num) ? item['skor_mato'] : 0;
        final income = (item['total_income'] is num) ? item['total_income'] : 0;
        item['income_per_mato'] = skor > 0 ? (income / skor) : 0;
      }

      _sortData(listData);

      setState(() {
        data = listData;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        data = [];
        isLoading = false;
      });
    }
  }

  void _sortData(List<Map<String, dynamic>> listData) {
    listData.sort((a, b) {
      dynamic valA = a[sortField] ?? 0;
      dynamic valB = b[sortField] ?? 0;

      if (sortField == 'nama_cabang') {
        return sortOrder == 'asc'
            ? valA.toString().compareTo(valB.toString())
            : valB.toString().compareTo(valA.toString());
      } else if (valA is num && valB is num) {
        return sortOrder == 'asc' ? valA.compareTo(valB) : valB.compareTo(valA);
      } else {
        return 0;
      }
    });
  }

  String formatRupiah(dynamic number) {
    if (number is String) return number;
    if (number is! num) return '-';
    return NumberFormat.currency(
        locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0)
        .format(number);
  }

  void _onSortChanged() {
    setState(() {
      _sortData(data);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Filter
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: DropdownButton<String>(
                  value: sortField,
                  isExpanded: true,
                  items: const [
                    DropdownMenuItem(
                        value: 'nama_cabang', child: Text('Nama Cabang (A-Z)')),
                    DropdownMenuItem(
                        value: 'skor_mato', child: Text('Jumlah Mato')),
                    DropdownMenuItem(
                        value: 'total_income', child: Text('Total Income')),
                    DropdownMenuItem(
                        value: 'income_per_mato',
                        child: Text('Income per Mato')),
                  ],
                  onChanged: (value) {
                    sortField = value!;
                    _onSortChanged();
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: DropdownButton<String>(
                  value: sortOrder,
                  isExpanded: true,
                  items: const [
                    DropdownMenuItem(
                        value: 'asc', child: Text('Urut Naik (Asc)')),
                    DropdownMenuItem(
                        value: 'desc', child: Text('Urut Turun (Desc)')),
                  ],
                  onChanged: (value) {
                    sortOrder = value!;
                    _onSortChanged();
                  },
                ),
              ),
            ],
          ),
        ),

        // Header
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 38, vertical: 2),
          child: Row(
            children: const [
              Expanded(flex: 1, child: Center(child: Text('Rank', style: TextStyle(fontWeight: FontWeight.bold)))),
              Expanded(flex: 3, child: Center(child: Text('Cabang', style: TextStyle(fontWeight: FontWeight.bold)))),
              Expanded(flex: 2, child: Center(child: Text('Jumlah Mato', style: TextStyle(fontWeight: FontWeight.bold)))),
              Expanded(flex: 3, child: Center(child: Text('Total Income', style: TextStyle(fontWeight: FontWeight.bold)))),
              Expanded(flex: 3, child: Center(child: Text('Income per Mato', style: TextStyle(fontWeight: FontWeight.bold)))),
            ],
          ),
        ),

        const SizedBox(height: 10),

        // Konten
        Transform.translate(
          offset: const Offset(0, -60),
          child: isLoading
              ? const Padding(
            padding: EdgeInsets.all(20),
            child: CircularProgressIndicator(),
          )
              : data.isEmpty
          // Placeholder jika kosong
              ? ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 1,
            itemBuilder: (context, index) {
              return _buildCardRow(
                index: 0,
                namaCabang: "-",
                skorMato: "-",
                totalIncome: "-",
                incomePerMato: "-",
                isTop: false,
                isBottom: false,
              );
            },
          )
          // Data asli dengan animasi
              : AnimatedList(
            key: _listKey,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            initialItemCount: data.length,
            itemBuilder: (context, index, animation) {
              final item = data[index];
              return SizeTransition(
                sizeFactor: animation,
                child: _buildCardRow(
                  index: index,
                  namaCabang: item['nama_cabang'] ?? "-",
                  skorMato: item['skor_mato'] ?? "-",
                  totalIncome: formatRupiah(item['total_income']),
                  incomePerMato: formatRupiah(item['income_per_mato']),
                  isTop: index == 0,
                  isBottom: index == data.length - 1,
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildCardRow({
    required int index,
    required String namaCabang,
    required dynamic skorMato,
    required dynamic totalIncome,
    required dynamic incomePerMato,
    required bool isTop,
    required bool isBottom,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Card(
        margin: EdgeInsets.zero,
        color: isTop && namaCabang != "-" ? Colors.green.shade100
            : isBottom && namaCabang != "-" ? Colors.red.shade100
            : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(flex: 1, child: Center(child: Text('${index + 1}'))),
              Expanded(flex: 3, child: Center(child: Text(namaCabang))),
              Expanded(flex: 2, child: Center(child: Text(skorMato.toString()))),
              Expanded(flex: 3, child: Center(child: Text(totalIncome.toString()))),
              Expanded(flex: 3, child: Center(child: Text(incomePerMato.toString()))),
            ],
          ),
        ),
      ),
    );
  }
}


