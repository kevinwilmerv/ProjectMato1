import 'package:flutter/material.dart';

class LaporanLRPage extends StatelessWidget {
  const LaporanLRPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Laporan Laba Rugi")),
      body: const Center(child: Text("Isi laporan laba rugi di sini")),
    );
  }
}
