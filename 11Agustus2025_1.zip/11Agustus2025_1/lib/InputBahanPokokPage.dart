import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:laporan_keuangan1/log_service.dart';


class InputBahanPokokPage extends StatefulWidget {
  final String cabangId;
  const InputBahanPokokPage({super.key, required this.cabangId});

  @override
  State<InputBahanPokokPage> createState() => _InputBahanPokokPageState();
}

class _InputBahanPokokPageState extends State<InputBahanPokokPage> {
  DateTime _selectedDate = DateTime.now();
  final TextEditingController _jenisController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();

  Map<String, List<Map<String, TextEditingController>>> _data = {};
  Map<String, List<String>> _usedIds = {};
  Map<String, List<String>> _reusableIds = {};
  String get _storageKey => 'bahan_pokok_${DateFormat('yyyy-MM-dd').format(_selectedDate)}';

  String? _idCabangFromProfile;

  void _addJenis() {
    final jenis = _jenisController.text.trim();
    if (jenis.isEmpty || _data.containsKey(jenis)) return;
    setState(() {
      _data[jenis] = [];
      _usedIds[jenis] = [];
      _reusableIds[jenis] = [];
      _jenisController.clear();
    });

    // ✅ Log Aktivitas
    logService.addLog(
      aktivitas: 'Tambah Kategori',
      halaman: 'Input Bahan Pokok',
      detail: 'Kategori $jenis - ${DateFormat('yyyy-MM-dd').format(_selectedDate)}',
    );
  }

  void _addBarang(String jenis) {
    final id = _generateId(jenis);
    setState(() {
      _data[jenis]!.add({
        'id': TextEditingController(text: id),
        'nama': TextEditingController(),
        'jumlah': TextEditingController(),
        'satuan': TextEditingController(),
        'harga': TextEditingController(),
      });
    });

    // ✅ Log Aktivitas
    logService.addLog(
      aktivitas: 'Tambah Barang',
      halaman: 'Input Bahan Pokok',
      detail: 'Jenis: $jenis - Tanggal: ${DateFormat('yyyy-MM-dd').format(_selectedDate)}',
    );
  }

  @override
  void initState() {
    super.initState();
    _loadDataForDate(_selectedDate);
    _fetchCabangFromUser();
  }

  Future<void> _fetchCabangFromUser() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) return;

    final userProfile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    setState(() {
      _idCabangFromProfile = userProfile?['id_cabang'];
      print('✅ Cabang dari user: $_idCabangFromProfile');
    });
  }

  Future<void> _loadDataForDate(DateTime date) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'bahan_pokok_${DateFormat('yyyy-MM-dd').format(date)}';
    final raw = prefs.getString(key);
    final rawUsed = prefs.getString('used_ids_${DateFormat('yyyy-MM-dd').format(date)}');
    final rawReused = prefs.getString('reused_ids_${DateFormat('yyyy-MM-dd').format(date)}');

    _data.clear();
    _usedIds.clear();
    _reusableIds.clear();

    if (raw != null) {
      final parsed = jsonDecode(raw);
      parsed.forEach((jenis, items) {
        _data[jenis] = List<Map<String, TextEditingController>>.from(
          (items as List).map((item) => {
            'id': TextEditingController(text: item['id']),
            'nama': TextEditingController(text: item['nama']),
            'jumlah': TextEditingController(text: item['jumlah']),
            'satuan': TextEditingController(text: item['satuan']),
            'harga': TextEditingController(text: item['harga']),
          }),
        );
      });
    }

    if (rawUsed != null) {
      final parsed = jsonDecode(rawUsed);
      parsed.forEach((jenis, list) {
        _usedIds[jenis] = List<String>.from(list);
      });
    }

    if (rawReused != null) {
      final parsed = jsonDecode(rawReused);
      parsed.forEach((jenis, list) {
        _reusableIds[jenis] = List<String>.from(list);
      });
    }

    setState(() {});
  }

  Future<void> _saveData() async {
    if (_idCabangFromProfile == null || _idCabangFromProfile!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Gagal menyimpan: ID Cabang belum tersedia. Coba lagi."),
        ),
      );
      print("❌ Simpan dibatalkan karena id_cabang masih null");
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    final tanggal = DateFormat('yyyy-MM-dd').format(_selectedDate);

    final supabase = Supabase.instance.client;

    try {
      final jsonData = _data.map((jenis, items) => MapEntry(
        jenis,
        items.map((item) => {
          'id': item['id']!.text,
          'nama': item['nama']!.text,
          'jumlah': item['jumlah']!.text,
          'satuan': item['satuan']!.text,
          'harga': item['harga']!.text,
        }).toList(),
      ));
      await prefs.setString(_storageKey, jsonEncode(jsonData));
      await prefs.setString('used_ids_$tanggal', jsonEncode(_usedIds));
      await prefs.setString('reused_ids_$tanggal', jsonEncode(_reusableIds));

      for (var entry in _data.entries) {
        final jenis = entry.key;
        for (var item in entry.value) {
          final jumlah = num.tryParse(item['jumlah']!.text) ?? 0;
          final harga = num.tryParse(item['harga']!.text) ?? 0;

          final response = await supabase.from('bahan_pokok').upsert({
            'id_cabang': _idCabangFromProfile,
            'tanggal': tanggal,
            'jenis': jenis,
            'id_bahan': item['id']!.text,
            'nama_bahan': item['nama']!.text,
            'jumlah': jumlah,
            'harga': harga,
            'total': jumlah * harga,
          }, onConflict: 'id_cabang,tanggal,id_bahan');

          if (response != null && response.error != null) {
            throw response.error!;
          }
        }
      }

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Data berhasil disimpan ke Supabase")),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Gagal menyimpan: $e")),
        );
      }
    }
  }

  Future<void> _copyFromYesterday() async {
    final yesterday = _selectedDate.subtract(const Duration(days: 1));
    final prefs = await SharedPreferences.getInstance();
    final key = 'bahan_pokok_${DateFormat('yyyy-MM-dd').format(yesterday)}';
    final data = prefs.getString(key);
    final used = prefs.getString('used_ids_${DateFormat('yyyy-MM-dd').format(yesterday)}');
    final reused = prefs.getString('reused_ids_${DateFormat('yyyy-MM-dd').format(yesterday)}');
    if (data != null) await prefs.setString(_storageKey, data);
    if (used != null) await prefs.setString('used_ids_${DateFormat('yyyy-MM-dd').format(_selectedDate)}', used);
    if (reused != null) await prefs.setString('reused_ids_${DateFormat('yyyy-MM-dd').format(_selectedDate)}', reused);
    await _loadDataForDate(_selectedDate);
  }

  String _generateId(String jenis) {
    String prefix;
    final parts = jenis.trim().split(RegExp(r'\s+'));
    if (parts.length == 1) {
      prefix = parts[0].toUpperCase().padRight(3, 'X').substring(0, 3);
    } else {
      prefix = parts[0][0].toUpperCase() +
          parts[1][0].toUpperCase() +
          parts[1].substring(parts[1].length - 1).toUpperCase();
    }

    if (_reusableIds[jenis]?.isNotEmpty ?? false) {
      final id = _reusableIds[jenis]!.removeAt(0);
      _usedIds[jenis]!.add(id);
      return id;
    }

    int count = _usedIds[jenis]?.length ?? 0;
    String newId;
    do {
      newId = '$prefix${(count + 1).toString().padLeft(3, '0')}';
      count++;
    } while (_usedIds[jenis]?.contains(newId) ?? false);

    _usedIds[jenis] = [...?_usedIds[jenis], newId];
    return newId;
  }

  void _hapusBarang(String jenis, int index) {
    final id = _data[jenis]![index]['id']!.text;
    _reusableIds[jenis]!.add(id);
    _usedIds[jenis]!.remove(id);
    setState(() {
      _data[jenis]![index].values.forEach((e) => e.dispose());
      _data[jenis]!.removeAt(index);
    });
  }

  void _hapusJenis(String jenis) {
    setState(() {
      _data[jenis]!.forEach((item) {
        item.values.forEach((controller) => controller.dispose());
      });
      _data.remove(jenis);
      _usedIds.remove(jenis);
      _reusableIds.remove(jenis);
    });
  }

  InputDecoration _whiteUnderlineInput(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.black),
      enabledBorder: const UnderlineInputBorder(
        borderSide: BorderSide(color: Colors.white),
      ),
      focusedBorder: const UnderlineInputBorder(
        borderSide: BorderSide(color: Colors.white, width: 2),
      ),
    );
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2024),
      lastDate: DateTime(2100),
    );

    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
      _loadDataForDate(picked);
    }
  }


  @override
  Widget build(BuildContext context) {
    final search = _searchController.text.trim().toLowerCase();

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: const Text('Input Biaya Bahan Pokok'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.black,
        actions: [
          IconButton(icon: const Icon(Icons.calendar_today), onPressed: _pickDate),
          IconButton(icon: const Icon(Icons.copy), onPressed: _copyFromYesterday),
        ],
      ),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFFFC5CC), Colors.white],
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Tanggal: ${DateFormat('EEEE, dd MMM yyyy').format(_selectedDate)}',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextField(
                    controller: _searchController,
                    onChanged: (_) => setState(() {}),
                    decoration: InputDecoration(
                      hintText: 'Cari ID atau Nama Barang',
                      prefixIcon: const Icon(Icons.search),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _jenisController,
                          decoration: InputDecoration(
                            labelText: 'Tambah Kategori',
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        onPressed: _addJenis,
                        icon: const Icon(Icons.add_circle, color: Colors.teal),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    children: _data.entries.map((entry) {
                      final jenis = entry.key;
                      final items = entry.value.where((item) {
                        if (search.isEmpty) return true;
                        return item['id']!.text.toLowerCase().contains(search) ||
                            item['nama']!.text.toLowerCase().contains(search);
                      }).toList();

                      return Card(
                        elevation: 4,
                        margin: const EdgeInsets.only(bottom: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                        child: ExpansionTile(
                          title: Text(jenis, style: const TextStyle(fontWeight: FontWeight.bold)),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _hapusJenis(jenis),
                          ),
                          children: [
                            ...items.asMap().entries.map((e) {
                              final index = e.key;
                              final item = e.value;
                              return Card(
                                elevation: 2,
                                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                color: const Color(0xFFFFFFFF),
                                child: Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Column(
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(child: TextFormField(controller: item['id'], readOnly: true, decoration: _whiteUnderlineInput('ID'))),
                                          const SizedBox(width: 12),
                                          Expanded(child: TextFormField(controller: item['nama'], decoration: _whiteUnderlineInput('Nama Barang'))),
                                        ],
                                      ),
                                      const SizedBox(height: 12),
                                      Row(
                                        children: [
                                          Expanded(child: TextFormField(controller: item['jumlah'], keyboardType: TextInputType.number, decoration: _whiteUnderlineInput('Jumlah'))),
                                          const SizedBox(width: 12),
                                          Expanded(child: TextFormField(controller: item['satuan'], decoration: _whiteUnderlineInput('Satuan'))),
                                        ],
                                      ),
                                      const SizedBox(height: 12),
                                      Row(
                                        children: [
                                          Expanded(child: TextFormField(controller: item['harga'], keyboardType: TextInputType.number, decoration: _whiteUnderlineInput('Harga per Item'))),
                                          IconButton(
                                            onPressed: () => _hapusBarang(jenis, index),
                                            icon: const Icon(Icons.delete, color: Colors.red),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }),
                            TextButton.icon(
                              onPressed: () => _addBarang(jenis),
                              icon: const Icon(Icons.add),
                              label: const Text('Tambah Barang'),
                            ),
                            const SizedBox(height: 12),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: ElevatedButton.icon(
                    onPressed: _saveData,
                    icon: const Icon(Icons.save),
                    label: const Text("Simpan Semua"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      minimumSize: const Size.fromHeight(50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
