import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class LogPage extends StatefulWidget {
  const LogPage({super.key});

  @override
  State<LogPage> createState() => _LogPageState();
}

class _LogPageState extends State<LogPage> {
  final supabase = Supabase.instance.client;
  List<Map<String, dynamic>> logs = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchLogs();

    // Realtime update
    supabase
        .from('log_aktivitas')
        .stream(primaryKey: ['id'])
        .order('waktu', ascending: false)
        .listen((data) {
      setState(() {
        logs = List<Map<String, dynamic>>.from(data);
      });
    });
  }

  Future<void> fetchLogs() async {
    setState(() => isLoading = true);
    try {
      final user = supabase.auth.currentUser;
      if (user == null) throw Exception("User belum login");

      final profile = await supabase
          .from('profiles')
          .select('id_cabang')
          .eq('id', user.id)
          .maybeSingle();

      final idCabang = profile?['id_cabang'];

      final response = await supabase
          .from('log_aktivitas')
          .select()
          .eq('id_cabang', idCabang) // ← filter cabang
          .order('waktu', ascending: false);

      setState(() {
        logs = List<Map<String, dynamic>>.from(response);
        isLoading = false;
      });
    } catch (e) {
      print("❌ Gagal mengambil log: $e");
      setState(() => isLoading = false);
    }
  }

  String formatWaktu(String waktuIso) {
    final date = DateTime.tryParse(waktuIso);
    if (date == null) return waktuIso;
    return DateFormat('dd MMM yyyy HH:mm:ss', 'id_ID').format(date);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Log Aktivitas"),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
        onRefresh: fetchLogs,
        child: logs.isEmpty
            ? const Center(
          child: Text("Belum ada log aktivitas"),
        )
            : ListView.builder(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          itemCount: logs.length,
          itemBuilder: (context, index) {
            final log = logs[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "${log['aktivitas']} - ${log['halaman']}",
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(log['detail'] ?? ''),
                    const SizedBox(height: 4),
                    Text(
                      formatWaktu(log['waktu'] ?? ''),
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
