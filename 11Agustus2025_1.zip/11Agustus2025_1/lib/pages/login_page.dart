import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:laporan_keuangan1/dashboard/dashboard_cabang.dart';
import 'package:laporan_keuangan1/log_service.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final supabase = Supabase.instance.client;
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  bool isLoading = false;

  void showMessage(String message, {bool success = false}) {
    final color = success ? Colors.green : Colors.red;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: color),
    );
  }

  Future<void> login() async {
    final email = emailController.text.trim();
    final password = passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      showMessage("Email dan password wajib diisi.");
      return;
    }

    setState(() => isLoading = true);

    try {
      final response = await supabase.auth.signInWithPassword(
        email: email,
        password: password,
      );

      final user = response.user;
      if (user == null) {
        showMessage("Login gagal. Pengguna tidak ditemukan.");
        return;
      }

      final userData = await supabase
          .from('profiles')
          .select('nama, role, id_cabang')
          .eq('id', user.id)
          .maybeSingle();

      if (userData == null) {
        showMessage("Data pengguna tidak ditemukan.");
        return;
      }

      final role = userData['role'] ?? '';
      final nama = userData['nama'] ?? '';
      final idCabang = userData['id_cabang'];

      // Catat log login setiap kali berhasil login
      try {
        final logService = LogService();
        await logService.addLog(
          aktivitas: "Login",
          halaman: "Auth",
          detail: "User $nama ($role) berhasil login",
        );
      } catch (logError) {
        debugPrint("⚠ Gagal mencatat log login: $logError");
      }

      showMessage("Selamat datang, $nama ($role)", success: true);

      if (role == 'admin_pusat') {
        // Arahkan ke DashboardAdmin tanpa perlu mengirimkan argumen
        Navigator.pushReplacementNamed(context, '/dashboard-admin');
      } else if (role == 'admin_cabang') {
        if (idCabang == null) {
          showMessage("ID Cabang tidak ditemukan untuk admin_cabang.");
          return;
        }

        final cabangData = await supabase
            .from('cabang')
            .select('nama_cabang')
            .eq('id_cabang', idCabang)
            .maybeSingle();

        final namaCabang = cabangData?['nama_cabang'] ?? 'Cabang';

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => DashboardCabang(
              idCabang: idCabang,
              namaCabang: namaCabang,
            ),
          ),
        );
      } else if (role == 'staff') {
        Navigator.pushReplacementNamed(context, '/dashboard_staff');
      } else {
        showMessage("Role tidak dikenali.");
      }
    } catch (e) {
      showMessage("Terjadi kesalahan saat login: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFD1D1), Colors.white],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: Card(
              color: Colors.white.withOpacity(0.95),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 10,
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      "Masuk Akun",
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 24),
                    TextField(
                      controller: emailController,
                      decoration: const InputDecoration(labelText: 'Email'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: passwordController,
                      obscureText: true,
                      decoration: const InputDecoration(labelText: 'Password'),
                    ),
                    const SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: isLoading ? null : login,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.indigo,
                        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: isLoading
                          ? const CircularProgressIndicator(color: Colors.white)
                          : const Text(
                        'Login',
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextButton(
                      onPressed: () => Navigator.pushReplacementNamed(context, '/register'),
                      child: const Text('Belum punya akun? Daftar di sini'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
