import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';

class LaporanInvestorPage extends StatefulWidget {
  final String idCabang;
  const LaporanInvestorPage({super.key, required this.idCabang});

  @override
  State<LaporanInvestorPage> createState() => _LaporanInvestorPageState();
}

class _LaporanInvestorPageState extends State<LaporanInvestorPage> {
  final supabase = Supabase.instance.client;
  DateTimeRange? selectedRange;

  int totalLabaBersih = 0;
  int bagianKaryawan = 0;
  int bagianDireksiInvestor = 0;
  int zakat = 0;
  int hasilBersihInvestor = 0;

  // contoh data pinjaman/bon (nanti bisa di-fetch dari Supabase)
  int pinjaman = 0;
  int bonMakan = 0;
  int bonGudang = 0;

  bool loading = false;

  final currencyFormat = NumberFormat.currency(
    locale: 'id_ID',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  Future<void> _pickDateRange() async {
    DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      initialDateRange: selectedRange,
    );

    if (picked != null) {
      setState(() {
        selectedRange = picked;
      });
      _fetchLabaBersih();
    }
  }

  Future<void> _fetchLabaBersih() async {
    if (selectedRange == null) return;
    setState(() => loading = true);

    try {
      final start = DateFormat('yyyy-MM-dd').format(selectedRange!.start);
      final end = DateFormat('yyyy-MM-dd').format(selectedRange!.end);

      final response = await supabase
          .from('laba_bersih')
          .select('total_laba_bersih')
          .eq('id_cabang', widget.idCabang)
          .gte('tanggal', start)
          .lte('tanggal', end);

      int total = 0;
      for (var row in response) {
        total += (row['total_laba_bersih'] ?? 0) as int;
      }

      int karyawan = (total * 0.5).round();
      int direksiInvestor = (total * 0.5).round();
      int zakatValue = (direksiInvestor * 0.025).round();
      int hasilInvestor = direksiInvestor - zakatValue;

      setState(() {
        totalLabaBersih = total;
        bagianKaryawan = karyawan;
        bagianDireksiInvestor = direksiInvestor;
        zakat = zakatValue;
        hasilBersihInvestor = hasilInvestor;
        loading = false;
      });
    } catch (e) {
      setState(() => loading = false);
      print("❌ Error: $e");
    }
  }

  Future<void> _exportPDF() async {
    final pdf = pw.Document();
    final currencyFormat = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

    pw.Widget buildRow(String title, dynamic value, {bool bold = false}) {
      return pw.Container(
        padding: const pw.EdgeInsets.symmetric(vertical: 2),
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Expanded(
              child: pw.Text(title,
                  style: pw.TextStyle(
                      fontSize: 10,
                      fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
            ),
            pw.Text(currencyFormat.format(value ?? 0),
                style: pw.TextStyle(
                    fontSize: 10,
                    fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
          ],
        ),
      );
    }

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (context) => [
          pw.Center(
            child: pw.Text(
              "LAPORAN PEMBAGIAN LABA UNTUK DIREKSI & INVESTOR",
              style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold),
            ),
          ),
          pw.SizedBox(height: 4),
          pw.Center(
            child: pw.Text(
              "Restoran Simpang Raya - Cabang KM 360B",
              style: const pw.TextStyle(fontSize: 10),
            ),
          ),
          pw.Center(
            child: pw.Text(
              "Periode: 6 Januari - 14 April 2020",
              style: const pw.TextStyle(fontSize: 10),
            ),
          ),
          pw.Center(
            child: pw.Text(
              "(100 Hari kerja)",
              style: const pw.TextStyle(fontSize: 10),
            ),
          ),
          pw.SizedBox(height: 10),

          // Laba Bersih
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text("1. Laba Bersih", style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              pw.Text(currencyFormat.format(totalLabaBersih),
                  style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            ],
          ),

          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text("2. Untuk Karyawan 50%", style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              pw.Text(currencyFormat.format(bagianKaryawan),
                  style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            ],
          ),

          pw.SizedBox(height: 4),
          buildRow("Pendapatan Bersih Direksi & Investor", bagianDireksiInvestor, bold: true),

          pw.SizedBox(height: 6),
          pw.Text("Pembagian Direksi Simpang Raya", style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          buildRow("Direksi 50%", bagianDireksiInvestor / 2),
          buildRow("Zakat (2.5%)", zakat),
          buildRow("Setelah Zakat", bagianDireksiInvestor / 2 - zakat, bold: true),

          pw.SizedBox(height: 6),
          pw.Text("Pinjaman & Bon Makan Direksi", style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          buildRow("Pinjaman", pinjaman),
          buildRow("Bon Makan", bonMakan),
          buildRow("Bon Gudang", bonGudang),
          buildRow("Total Pinjaman & Bon Makan", pinjaman + bonMakan + bonGudang, bold: true),
          buildRow("Hasil Bersih", (bagianDireksiInvestor / 2 - zakat) - (pinjaman + bonMakan + bonGudang), bold: true),

          pw.SizedBox(height: 10),

          // Bagian Investor
          pw.Text("Pembagian Investor", style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          buildRow("Investor 50%", bagianDireksiInvestor / 2),
          buildRow("Penerimaan dari Penyusutan", 0),
          buildRow("Total Laba untuk Investor", hasilBersihInvestor),
          buildRow("Laba dibagikan setelah Zakat", hasilBersihInvestor),
          buildRow("Setoran Revenue Sharing", 0),
          buildRow("Pinjaman", pinjaman),
          buildRow("Bon Makan", bonMakan),
          buildRow("Total Pinjaman & Bon Makan", pinjaman + bonMakan, bold: true),
          buildRow("Hasil Bersih Investor", hasilBersihInvestor - (pinjaman + bonMakan), bold: true),

          pw.SizedBox(height: 20),
          pw.Text(
            "Dicetak pada: ${DateFormat('dd MMMM yyyy', 'id_ID').format(DateTime.now())}",
            style: pw.TextStyle(fontSize: 9, color: PdfColors.grey600),
          ),
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
  }

  Widget _buildExpansionTile({
    required String title,
    required String value,
    Color? valueColor,
    List<Widget>? children,
  }) {
    return Card(
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      child: ExpansionTile(
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        trailing: Text(
          value,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            color: valueColor ?? Colors.green.shade800,
          ),
        ),
        children: children ?? [],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: false,
      appBar: AppBar(
        backgroundColor: const Color(0xFFFFC1CC),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
        title: const Text(
          "Laporan Investor",
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFC1CC), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 80),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade100,
                  foregroundColor: Colors.green.shade800,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                ),
                onPressed: _pickDateRange,
                child: const Text("Pilih Rentang Tanggal"),
              ),
              const SizedBox(height: 12),

              _buildExpansionTile(
                title: "Total Laba Bersih",
                value: currencyFormat.format(totalLabaBersih),
              ),
              _buildExpansionTile(
                title: "Bagian Karyawan (50%)",
                value: currencyFormat.format(bagianKaryawan),
              ),
              _buildExpansionTile(
                title: "Bagian Direksi + Investor (50%)",
                value: currencyFormat.format(bagianDireksiInvestor),
                children: [
                  ListTile(
                    title: const Text("Pembagian Direksi Simpang Raya"),
                    trailing: Text(currencyFormat
                        .format(bagianDireksiInvestor * 0.5)),
                  ),
                  ListTile(
                    title: const Text("Pembagian Investor"),
                    trailing: Text(currencyFormat
                        .format(bagianDireksiInvestor * 0.5)),
                  ),
                ],
              ),
              _buildExpansionTile(
                title: "Zakat (2.5%)",
                value: currencyFormat.format(zakat),
                valueColor: Colors.red,
              ),
              _buildExpansionTile(
                title: "Pinjaman & Bon Makan Direksi",
                value: currencyFormat.format(pinjaman + bonMakan + bonGudang),
                children: [
                  ListTile(
                    title: const Text("Pinjaman"),
                    trailing: Text(currencyFormat.format(pinjaman)),
                  ),
                  ListTile(
                    title: const Text("Bon Makan"),
                    trailing: Text(currencyFormat.format(bonMakan)),
                  ),
                  ListTile(
                    title: const Text("Bon Gudang"),
                    trailing: Text(currencyFormat.format(bonGudang)),
                  ),
                ],
              ),
              _buildExpansionTile(
                title: "Pembagian Investor (Detail)",
                value: currencyFormat.format(hasilBersihInvestor),
                children: [
                  ListTile(
                    title: const Text("Pembagian Investor 50%"),
                    trailing: Text(currencyFormat.format(bagianDireksiInvestor * 0.5)),
                  ),
                  ListTile(
                    title: const Text("Penerimaan dari Penyusutan"),
                    trailing: Text(currencyFormat.format(0)),
                  ),
                  ListTile(
                    title: const Text("Total Laba untuk Investor"),
                    trailing: Text(currencyFormat.format(hasilBersihInvestor)),
                  ),
                  ListTile(
                    title: const Text("Laba dibagikan untuk Investor"),
                    trailing: Text(currencyFormat.format(hasilBersihInvestor)),
                  ),
                  ListTile(
                    title: const Text("Setoran Revenue Sharing"),
                    trailing: Text(currencyFormat.format(0)),
                  ),
                  ListTile(
                    title: const Text("Pinjaman"),
                    trailing: Text(currencyFormat.format(pinjaman)),
                  ),
                  ListTile(
                    title: const Text("Bon Makan"),
                    trailing: Text(currencyFormat.format(bonMakan)),
                  ),
                  ListTile(
                    title: const Text("Total Pinjaman dan Bon Makan"),
                    trailing: Text(currencyFormat.format(pinjaman + bonMakan)),
                  ),
                ],
              ),
              _buildExpansionTile(
                title: "Hasil Bersih Investor",
                value: currencyFormat.format(hasilBersihInvestor),
                valueColor: Colors.blue,
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade200,
                  foregroundColor: Colors.green.shade800,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                ),
                onPressed: _exportPDF,
                icon: const Icon(Icons.picture_as_pdf),
                label: const Text("Export PDF"),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
